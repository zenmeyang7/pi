"""评测集自检：跑评测**之前**先确认这套题本身是成立的。

三道闸门，全是纯文本扫描，不需要 Ollama：

    ① gold 可达    每条 case 标注的 path + 行区间，必须真的落在至少一个
                    chunk 上。不可达 = 标注错了，不是检索错了 —— 不先查清
                    楚，后面四档的 recall 都是在替标注背锅。
    ② 符号漂移     query 点名了标识符（node_grade / _safe_path）时，gold
                    chunk 正文里必须真的有它。只查"可达"查不出漂移：行号
                    偏出去几十行照样落在别的 chunk 上，看着还是可达。
    ③ 对抗集不漏    out_of_scope 的 must_not 词在语料里必须 0 命中。
                    哪天 README 里写了句"下一步接 Redis"，那条题就从幻觉
                    题变成了漏检题，幻觉率会莫名其妙地涨。

    uv run python eval/corpus_langchain/check_set.py
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

HERE = os.path.dirname(os.path.abspath(__file__))
INDEX_DIR = os.path.join(ROOT, ".rag_index_langchain")
CASES = os.path.join(HERE, "cases.jsonl")

_TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+")


def load_cases(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def overlaps(meta, case):
    if meta["path"] != case["path"]:
        return False
    g0, g1 = case["lines"]
    r0, r1 = meta.get("start_line", 0), meta.get("end_line", 0)
    return r0 <= g1 and g0 <= r1


def main():
    from rag.store import IndexStore

    store = IndexStore(INDEX_DIR).load()
    if not store.chunks:
        print(f"索引是空的：{INDEX_DIR}")
        return 1
    print(f"[check] 索引 {len(store.chunks)} 个 chunk\n")

    cases = load_cases(CASES)
    sys.path.insert(0, HERE)
    from adversarial import ADVERSARIAL_CASES

    ok = True

    # ---- ① gold 可达 ----
    unreachable = []
    for c in cases:
        if not any(overlaps(ch["meta"], c) for ch in store.chunks):
            unreachable.append(f'{c["path"]}:{c["lines"][0]}  << {c["query"]}')
    print(f"① gold 可达：{len(cases) - len(unreachable)}/{len(cases)}")
    if unreachable:
        ok = False
        print("   不可达（改标注，不是改检索）：")
        for u in unreachable:
            print("     - " + u)
    else:
        print("   全部可达 ✓")

    # ---- ② 符号漂移 ----
    symbols = [ch["meta"].get("symbol") or "" for ch in store.chunks]
    drift = []
    for c in cases:
        gold = [ch for ch in store.chunks if overlaps(ch["meta"], c)]
        text = " ".join(ch["text"] for ch in gold).lower()
        named = {w for w in _TOKEN_RE.findall(c["query"])
                 if len(w) >= 4 and any(w in s for s in symbols)}
        lost = sorted(w for w in named if w.lower() not in text)
        if lost:
            drift.append(f'{c["path"]}:{c["lines"][0]}  << {c["query"][:24]}… '
                         f'正文里没有 {lost}')
    print(f"\n② 符号漂移：{len(cases) - len(drift)}/{len(cases)}")
    if drift:
        ok = False
        print("   疑似标错：")
        for d in drift:
            print("     - " + d)
    else:
        print("   无漂移 ✓")

    # ---- ③ 对抗集不漏 ----
    text = "\n".join(c["text"] for c in store.chunks).lower()
    leaked = [f'{a["query"][:18]}… 语料里出现了「{w}」'
              for a in ADVERSARIAL_CASES for w in a.get("must_not", ())
              if w.lower() in text]
    n_adv = len(ADVERSARIAL_CASES)
    print(f"\n③ 对抗集不漏：{n_adv - len({a['query'] for a in ADVERSARIAL_CASES for w in a.get('must_not', ()) if w.lower() in text})}/{n_adv}")
    if leaked:
        ok = False
        print("   这些主题语料里其实有（该换题，不是该改检索）：")
        for l in leaked:
            print("     - " + l)
    else:
        print("   全部真的答不出 ✓")

    kinds = {a["kind"] for a in ADVERSARIAL_CASES}
    n_out = sum(1 for a in ADVERSARIAL_CASES if a["kind"] == "out_of_scope")
    print(f"\n   对抗集构成：out_of_scope {n_out} + near_miss {n_adv - n_out}")
    if kinds != {"out_of_scope", "near_miss"}:
        ok = False
        print("   两类都要有，否则看不出「域外好拒 / 近义难拒」的区别")

    print("\n" + ("全部通过 ✓" if ok else "有问题，先修评测集再跑评测 ✗"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
