# 检索评测：语料 = ai-agent-langchain-main

## 环境

| 项 | 值 |
|---|---|
| 索引 chunk 数 | 1205 |
| 可解答集 | 61 条（五方向各 6 条） |
| 对抗集 | 37 条（out_of_scope 10 + near_miss 8） |
| embedding | bge-m3 (Ollama) |
| rerank | cross-encoder |
| 拒答线 tau | 0.603 |
| top-k | 5 |

## 四档递进：召回率 + 对抗幻觉率

| 档位 | recall@5 | 幻觉@1 | 域外 | 近义 | 幻觉@5 | 可分性 |
|---|---|---|---|---|---|---|
| ① 切片 | 1.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.026 |
| ② +混合检索 | 0.705 | 0.000 | 0.000 | 0.000 | 0.000 | 0.066 |
| ③ +重排 | 0.754 | 0.000 | 0.000 | 0.000 | 0.000 | 0.045 |
| ④ +路由 | 0.754 | 0.000 | 0.000 | 0.000 | 0.000 | 0.031 |

## 五方向 × 四档 recall@5

| 方向 | ① 切片 | ② +混合检索 | ③ +重排 | ④ +路由 |
|---|---|---|---|---|
| 函数定位 | 1.000 | 1.000 | 0.917 | 0.917 |
| 类职责 | 1.000 | 0.833 | 0.833 | 0.833 |
| 调用关系 | 1.000 | 0.917 | 0.917 | 0.917 |
| 语义 | 1.000 | 0.385 | 0.769 | 0.769 |
| 模糊描述 | 1.000 | 0.417 | 0.333 | 0.333 |
| **全部** | 1.000 | 0.705 | 0.754 | 0.754 |

## 各策略详细

| strategy | recall@5 | mrr@5 | ndcg@5 | p50_ms |
|---|---|---|---|---|
| lexical | 0.443 | 0.344 | 0.368 | 1 |
| vector | 0.787 | 0.684 | 0.710 | 36 |
| hybrid | 0.705 | 0.583 | 0.614 | 38 |
| hybrid_routed | 0.787 | 0.644 | 0.680 | 39 |
| hybrid+rerank_noroute | 0.754 | 0.607 | 0.644 | 3199 |
| hybrid+rerank+route | 0.754 | 0.607 | 0.644 | 3023 |

## 漏检明细

路径格式 `p01/agent.py:124` = project_01 的 agent.py 第 124 行起（30 个项目里几乎每个都有 agent.py，只写文件名会分不清是谁掉的）。

| strategy | 漏检 | gold |
|---|---|---|
| lexical | 34/61 | p01/agent.py:124, p02/agent.py:102, p02/tools/file_tool.py:11, p10/tools/resume_scorer.py:81, p02/memory.py:95, p03/config.py:11, p11/tools/contract_analyzer.py:60, p05/agent.py:56, p09/agent.py:82, p01/tools/retriever.py:209, p01/agent.py:102, p02/memory.py:116, p03/agent.py:159, p01/tools/retriever.py:67, p02/agent.py:59, p13/agent.py:32, p13/tools/symptom_checker.py:59, p12/agent.py:18, p14/tools/lead_scorer.py:74, p25/tools/rss_collector.py:76, p11/tools/contract_analyzer.py:81, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176, p09/tools/browser_tool.py:69, p12/tools/technical_indicators.py:55, p10/tools/report_tool.py:24, p25/tools/brief_generator.py:105, p13/tools/ehr_summary.py:59, p06/tools/code_executor.py:79 |
| vector | 13/61 | p03/config.py:11, p11/tools/contract_analyzer.py:60, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p09/tools/browser_tool.py:69, p06/tools/code_executor.py:79 |
| hybrid | 18/61 | p03/config.py:11, p11/tools/contract_analyzer.py:60, p02/agent.py:102, p01/tools/retriever.py:209, p01/agent.py:102, p02/memory.py:116, p03/agent.py:159, p01/tools/retriever.py:67, p02/agent.py:59, p25/tools/rss_collector.py:76, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p09/tools/browser_tool.py:69, p06/tools/code_executor.py:79 |
| hybrid_routed | 13/61 | p03/config.py:11, p11/tools/contract_analyzer.py:60, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p09/tools/browser_tool.py:69, p06/tools/code_executor.py:79 |
| hybrid+rerank_noroute | 15/61 | p09/tools/task_parser.py:55, p03/config.py:11, p25/tools/brief_generator.py:16, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176, p09/tools/browser_tool.py:69, p06/tools/code_executor.py:79 |
| hybrid+rerank+route | 15/61 | p09/tools/task_parser.py:55, p03/config.py:11, p25/tools/brief_generator.py:16, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p05/tools/rbac.py:20, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176, p09/tools/browser_tool.py:69, p06/tools/code_executor.py:79 |

路由让词法路发言 36/61 条 query。
