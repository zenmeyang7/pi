"""评测的执行层：真跑检索、把原始结果摊平、算指标。**不打印、不 argparse**。

    collect_raw()   慢：6 策略 × 98 条 query，要 Ollama + 重排在线
        |  dump_raw() / load_raw()          <- raw_hits.json
        v
    build_experiment()   快且纯：只吃 hits + 余弦 + 延迟，算出全部指标

为什么要中间那份夹具：③④ 走 cross-encoder（ONNX CPU），一次全量跑是分钟级、
还依赖服务状态。重构期间每改一个文件都重跑一遍来证明"数字没变"不现实；把检索
结果**连同余弦和延迟**一起冻进文件后，验证变成秒级且可逐位复现（延迟也冻住了，
p50/p95 才谈得上可复现）。live 与 from-raw 两条路共用同一份数据结构，所以不存在
两套打分逻辑——这正是"重构不改数字"的保证方式。

⚠️ 本模块顶层 import eval.metrics，而它会把 rag.config 一起拉进来（rag/config.py
   是**导入时求值**的）。因此本模块只能在 run_eval.py 的 load_dotenv **之后**被导入：
   那块 `# noqa: E402` 的导入区不要往上挪。本模块自身不直接 import rag.*——
   retriever / store 都是调用方传进来的对象（鸭子类型），要类型注解时用 TYPE_CHECKING。
"""
from __future__ import annotations

import json
import math
import time
from collections import defaultdict
from dataclasses import asdict, dataclass
from hashlib import sha256
from typing import TYPE_CHECKING, Callable

from eval.metrics import (CAT_LABELS, abstention_auc, calibrate_tau,  # noqa: E402
                          chunk_coverage, far_from_scores, latency_stats,
                          mrr, ndcg_at_k, recall_at_k, routing_gain,
                          score_hits, vec_index)

if TYPE_CHECKING:
    from rag.retriever import Retriever
    from rag.store import IndexStore

# 四档严格累加：后者 = 前者 + 正好一个组件，所以档与档之间的差就是那个组件的净贡献。
# s=None 是"不检索"的那一档：它不返回任何 chunk，**没有检索成绩可报**，报的是
# Chunk Coverage（gold 有没有被切进 chunk）——那是数据集健康度，不是检索引擎的能力。
# 拿它当"切片档的 recall@5"是这份评测以前最容易误读的一格。
#
# 这里不复用 eval.metrics.STAGES：那条是 pi 自己语料上的口径，两者将来还会各自演进，
# 复用一个常量会让"改一处、另一个报告跟着变"这种事故无声发生。
LADDER: list[tuple[str, str | None]] = [
    ("① Chunk Coverage", None),
    ("② Hybrid", "hybrid"),
    ("③ Hybrid+Rerank", "hybrid+rerank_noroute"),
    ("④ Hybrid+Rerank+Route", "hybrid+rerank+route"),
]

# 夹具只存打分真正用得上的字段：meta（判命中）+ cos（判幻觉）。
# 为什么保留 "meta" 这个键、而不是摊平成 {path, start_line, ...}：eval.metrics 的
# is_hit / recall_at_k / mrr / ndcg_at_k 都是按 {"meta": {...}} 取的，保持这个形状
# 就能**原样复用**它们。换个形状就得再写一套等价判定，那种重复迟早会分叉。
def _compact(hits: list[dict], cosines: list[float]) -> list[dict]:
    """检索结果 -> 夹具条目（丢掉 text/id：能占体积九成，打分一条都用不上）。"""
    return [{"meta": {"path": h["meta"]["path"],
                      "start_line": h["meta"].get("start_line", 0),
                      "end_line": h["meta"].get("end_line", 0)},
             "cos": c}
            for h, c in zip(hits, cosines)]


def top_confidence(hits: list[dict], at: int | None = None) -> float:
    """一次检索结果里最高的自信度（前 at 条内；at=None 表示全部）。

    这就是 eval.metrics.score_hits(...)+max 的等价物，只是余弦在采集时就算好存进
    夹具了，这里不再需要 query 向量和向量表——也正因如此，from-raw 路径不需要
    Ollama 就能算出 FAR。
    """
    window = hits[:at] if at else hits
    return max((h.get("cos", 0.0) for h in window), default=0.0)


def corpus_best_score(qvec: list[float], chunks: list[dict]) -> float:
    """全库最高余弦 = **不做检索**（把整个仓库塞给模型）时的自信度上界。

    两处用途：① 可解答集的这一列取 p10 就是拒答线 tau（换模型/换语料自动重标定）；
    ② 对抗集的这一列就是"无检索基线"的 FAR——四档之外的一个对照组：连召回都省了，
    直接把全库最像的 chunk 递上去，会错到什么程度。
    """
    return max((math.sumprod(qvec, ch["vec"]) for ch in chunks), default=0.0)


def _digest(items: list[dict]) -> str:
    """评测集内容指纹：夹具是"某一刻的检索结果"，题变了它就该作废。"""
    blob = json.dumps(items, ensure_ascii=False, sort_keys=True)
    return sha256(blob.encode("utf-8")).hexdigest()[:12]


def _label(case: dict) -> str:
    return f'{case["path"]}:{case.get("lines", [0])[0]}'


def collect_raw(retriever: "Retriever", store: "IndexStore",
                cases: list[dict], adv: list[dict], strategies: list[str],
                vectors: dict[str, list[float]], k: int,
                embed_model: str = "",
                on_strategy_done: Callable[[str, list[float]], None] | None = None,
                ) -> dict:
    """真跑一遍检索，返回夹具结构（= raw_hits.json 的内容）。

    vectors：query 原文 -> 已归一化向量。批量 embedding 由调用方做一次（逐条调
    Ollama 每次约 2s），这里只取用。

    on_strategy_done：每跑完一个策略回调一次（进度打印留在 CLI 层——执行层不打印）。
    """
    vby = vec_index(store)
    hits: dict[str, dict] = {}
    latency: dict[str, list[float]] = {}

    for s in strategies:
        lat, case_hits = [], []
        for c in cases:
            # 计时只覆盖**可解答集**（与历史口径一致）：把对抗集也计进来会悄悄
            # 改掉 p50/p95 的分母，两次跑的延迟就没法比了。
            t = time.perf_counter()
            got = retriever.retrieve_by_strategy(c["query"], s, k=k)
            lat.append((time.perf_counter() - t) * 1000)
            case_hits.append(_compact(got, score_hits(got, vectors[c["query"]], vby)))

        adv_hits = []
        for a in adv:
            got = retriever.retrieve_by_strategy(a["query"], s, k=k)
            adv_hits.append(_compact(got, score_hits(got, vectors[a["query"]], vby)))

        hits[s] = {"cases": case_hits, "adv": adv_hits}
        latency[s] = lat
        if on_strategy_done is not None:
            on_strategy_done(s, lat)

    coverage, uncovered, gold_counts = chunk_coverage(store.chunks, cases)
    return {
        "meta": {
            "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "k": k,
            "embed_model": embed_model,
            "reranker_name": getattr(retriever.reranker, "name", "unknown"),
            "strategies": list(strategies),
            "chunk_count": len(store.chunks),
            "n_cases": len(cases),
            "n_adv": len(adv),
            # 指纹：from-raw 时用它挡住"夹具是旧题的"这种静默错配
            "cases_sha": _digest(cases),
            "adv_sha": _digest(adv),
        },
        "hits": hits,
        "latency": latency,
        # 无检索基线与 tau 标定都只需要这两个数（不是 chunk，省掉全库向量）
        "pos_best": [corpus_best_score(vectors[c["query"]], store.chunks) for c in cases],
        "corpus_top1": [corpus_best_score(vectors[a["query"]], store.chunks) for a in adv],
        # 路由是否放行词法路，只取决于 query 和索引（跟跑哪个策略无关），
        # 所以采一次就够，四档共用
        "distinctive": {
            "cases": [bool(store.has_distinctive_code_token(c["query"])) for c in cases],
            "adv": [bool(store.has_distinctive_code_token(a["query"])) for a in adv],
        },
        "coverage": {
            "value": coverage,
            "uncovered": [_label(c) for c in uncovered],
            "gold_chunk_counts": gold_counts,
        },
    }


def dump_raw(raw: dict, path: str) -> str:
    """写夹具。**别用 .jsonl 后缀**：仓库 .gitignore 第 22 行是 `*.jsonl`，会被吞掉。"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(raw, f, ensure_ascii=False, indent=1)
        f.write("\n")
    return path


def load_raw(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_raw(raw: dict, cases: list[dict], adv: list[dict], k: int) -> list[str]:
    """夹具与当前评测集/参数是否还对得上；返回不一致项（空列表 = 一致）。

    为什么必须校验：夹具是个快照，题改了、top-k 改了、评测集扩了，它就该作废。
    不校验的话，旧夹具算出来的数会安安静静地出现在报告里，而且比"跑错了"更难发现
    ——数字看着完全正常。
    """
    m = raw.get("meta", {})
    problems = []
    if not raw.get("hits"):
        return ["夹具里没有 hits"]
    if m.get("k") != k:
        problems.append(f"top-k 不一致：夹具 {m.get('k')} vs 本次 {k}")
    if m.get("n_cases") != len(cases):
        problems.append(f"可解答集条数不一致：夹具 {m.get('n_cases')} vs 本次 {len(cases)}")
    if m.get("n_adv") != len(adv):
        problems.append(f"对抗集条数不一致：夹具 {m.get('n_adv')} vs 本次 {len(adv)}")
    if m.get("cases_sha") and m["cases_sha"] != _digest(cases):
        problems.append("cases.jsonl 的内容和夹具不一致（换过题或改过标注）")
    if m.get("adv_sha") and m["adv_sha"] != _digest(adv):
        problems.append("adversarial.py 的内容和夹具不一致")
    return problems


@dataclass
class Experiment:
    """一次评测的全部产物。reporter 只读它，不再碰 raw/hits——报告与执行的接缝在这。

    字段值一律是普通 dict/list，不逐行建 dataclass：报告里到处是 f"recall@{k}" 这种
    动态键，包一层类型化对象只会逼着重写每一处取值，是重构改错数字的头号来源。
    """

    k: int
    meta: dict
    counts: dict                        # 条数：可解答/对抗/两类对抗/五方向各几条
    # 逐题的原文与 gold 坐标：报告要打"漏在哪、问的是什么"。存成裸数据（不做任何
    # 缩短/截断），怎么显示是 reporter 的事——evaluator 里一旦开始拼字符串，
    # 报告层就再也换不动排版了。
    case_queries: list[str]
    case_keys: list[str]
    # 对抗题原文与种类：报告要打"哪几道被错误接受了"，两类分开看才定位得到问题
    adv_queries: list[str]
    adv_kinds: list[str]
    strategies: list[str]
    ladder: list[tuple[str, str | None]]
    rows_by: dict[str, dict]            # 策略 -> recall/mrr/ndcg/p50/p95
    stage_rows: list[dict]              # 四档 × 全部分指标（含 FAR 拆分与可分性）
    cat_rows: dict[str, dict]           # 五方向 -> {档位: recall}
    all_row: dict[str, float | None]
    hit_flags: dict[str, list[bool]]    # 策略 -> 每题命中与否（漏检分析的原料）
    routing: dict                       # 路由净收益（两个对照 + 逐题救回/弄丢）
    coverage: dict                      # 不检索那一档的指标：gold 有没有被切进 chunk
    tau: float
    dropped: list[str]                  # 没测出来的档位（没有 cross-encoder 时）

    def to_dict(self) -> dict:
        return asdict(self)


def build_experiment(raw: dict, cases: list[dict], adv: list[dict], k: int,
                     strategies: list[str] | None = None) -> Experiment:
    """raw（live 采的或夹具读的）-> Experiment。纯函数：不碰网络、不写磁盘、不打印。

    指标的算术**照抄**原实现（连同 max(len,1) 这类分母保护）：重构期间"数字没变"
    要能逐位对上，靠的就是不在这一步顺手"改进"任何算式。
    """
    strategies = strategies if strategies is not None else list(raw["meta"]["strategies"])
    hits = raw["hits"]
    tau = calibrate_tau(raw["pos_best"], q=0.10)   # 拒答线：可解答集全库最高余弦的 p10
    cat_idxs = _cat_indices(cases)

    rows_by, hit_flags = _strategy_rows(raw, cases, k, strategies)
    stage_rows = _stage_rows(raw, hits, adv, cases, rows_by, k, tau)
    cat_rows, all_row = _category_rows(cases, hits, cat_idxs, rows_by, k,
                                       raw["coverage"]["gold_chunk_counts"])

    return Experiment(
        k=k,
        meta=dict(raw["meta"]),
        counts={
            "n_cases": len(cases),
            "n_adv": len(adv),
            "n_out": sum(1 for a in adv if a["kind"] == "out_of_scope"),
            "n_near": sum(1 for a in adv if a["kind"] == "near_miss"),
            "cats": {label: len(cat_idxs.get(key, [])) for key, label in CAT_LABELS},
        },
        case_queries=[c["query"] for c in cases],
        case_keys=[_label(c) for c in cases],
        adv_queries=[a["query"] for a in adv],
        adv_kinds=[a["kind"] for a in adv],
        strategies=strategies,
        ladder=LADDER,
        rows_by=rows_by,
        stage_rows=stage_rows,
        cat_rows=cat_rows,
        all_row=all_row,
        hit_flags=hit_flags,
        routing=_routing(raw, hits, cases, k, rows_by),
        coverage=dict(raw["coverage"]),
        tau=tau,
        dropped=[label for label, s in LADDER if s is not None and s not in rows_by],
    )


def _cat_indices(cases: list[dict]) -> dict[str, list[int]]:
    idxs: dict[str, list[int]] = defaultdict(list)
    for i, c in enumerate(cases):
        idxs[c.get("category", "other")].append(i)
    return idxs


def _strategy_rows(raw: dict, cases: list[dict], k: int,
                   strategies: list[str]) -> tuple[dict[str, dict], dict[str, list[bool]]]:
    """每个策略一行成绩：recall@k / mrr@k / ndcg@k / p50 / p95。

    顺手记下逐题命中与否（hit_flags）：漏检清单和路由的"救回/弄丢"都要用它，
    在这里算掉就不用再遍历一遍 hits。
    """
    hits, n = raw["hits"], max(len(cases), 1)
    rows_by: dict[str, dict] = {}
    hit_flags: dict[str, list[bool]] = {}
    for s in strategies:
        case_hits = hits[s]["cases"]
        rows_by[s] = {
            f"recall@{k}": sum(recall_at_k(r, c, k) for r, c in zip(case_hits, cases)) / n,
            f"mrr@{k}": sum(mrr(r, c, k) for r, c in zip(case_hits, cases)) / n,
            f"ndcg@{k}": sum(ndcg_at_k(r, c, k) for r, c in zip(case_hits, cases)) / n,
            **latency_stats(raw["latency"][s]),
        }
        hit_flags[s] = [recall_at_k(r, c, k) > 0 for r, c in zip(case_hits, cases)]
    return rows_by, hit_flags


def _stage_rows(raw: dict, hits: dict, adv: list[dict], cases: list[dict],
                rows_by: dict, k: int, tau: float) -> list[dict]:
    """四档每档一行。没测到的档位（缺 cross-encoder 时的 ③④）直接不出现——
    拿降级结果顶替会让人以为那是重排的成绩。

    不检索那一档的 recall / FAR / 延迟一律是 None：它没有检索动作，这些格子填任何
    数都是在暗示"它也是检索方案之一"。它的 FAR 值仍然算出来（作为"不检索基线"
    留给报告当脚注），只是不占成绩位。
    """
    out = []
    for label, s in LADDER:
        if s is not None and s not in rows_by:
            continue
        if s is None:                       # 不检索那一档
            # 自信度取全库最高余弦：不做任何召回、把整个仓库原样递上去会错到什么程度
            conf1 = conf_k = raw["corpus_top1"]
            pos1 = raw["pos_best"]
            recall, p50, p95 = None, None, None
            coverage = raw["coverage"]["value"]
        else:
            conf1 = [top_confidence(h, 1) for h in hits[s]["adv"]]
            conf_k = [top_confidence(h, k) for h in hits[s]["adv"]]
            pos1 = [top_confidence(h, 1) for h in hits[s]["cases"]]
            recall = rows_by[s][f"recall@{k}"]
            p50, p95 = rows_by[s]["p50_ms"], rows_by[s]["p95_ms"]
            coverage = None
        # 两类对抗题分开报：out_of_scope 只要拒答线设了就该全拒掉，near_miss 才是
        # 幻觉主产区。合成一个数会让"域外很好拒"盖住"近义很难拒"。
        out1 = [v for v, a in zip(conf1, adv) if a["kind"] == "out_of_scope"]
        near1 = [v for v, a in zip(conf1, adv) if a["kind"] == "near_miss"]
        out.append({
            "stage": label,
            "strategy": s,
            "coverage": coverage,
            "recall": recall,
            "p50_ms": p50,
            "p95_ms": p95,
            # FAR = False Acceptance Rate：本来没有答案的题，被递上了超过拒答线的
            # 上下文的比例。@1 看模型第一眼看到的，@k 看它手里那几条（更严）。
            "far": far_from_scores(conf1, tau),
            "far_out": far_from_scores(out1, tau),
            "far_near": far_from_scores(near1, tau),
            "far_at_k": far_from_scores(conf_k, tau),
            "auc": abstention_auc(pos1, conf1),
            "neg1": conf1,
        })
    return out


def _category_rows(cases: list[dict], hits: dict, cat_idxs: dict[str, list[int]],
                   rows_by: dict, k: int,
                   gold_counts: list[int]) -> tuple[dict[str, dict], dict[str, float | None]]:
    """五方向 × 四档 recall@k。不检索那一档报的是该方向的 **Chunk Coverage**。

    逐方向看覆盖率是有必要的：整体 coverage 0.98 很可能是某个方向的 gold 跨度
    恰好都落在 chunk 边界里，而另一个方向一半的标注压根切不到——那边后面所有档的
    recall 都在替标注背锅，横向比方向时会得出"这个方向语义难"的错误结论。
    """
    cat_rows: dict[str, dict] = {}
    for cat_key, cat_label in CAT_LABELS:
        idxs = cat_idxs.get(cat_key, [])
        if not idxs:
            continue
        row: dict[str, float | None] = {}
        for slabel, s in LADDER:
            if s is None:
                row[slabel] = sum(1 for i in idxs if gold_counts[i] > 0) / len(idxs)
            elif s in rows_by:
                row[slabel] = sum(recall_at_k(hits[s]["cases"][i], cases[i], k)
                                  for i in idxs) / len(idxs)
            else:
                row[slabel] = None
        cat_rows[cat_label] = row
    all_row: dict[str, float | None] = {}
    for slabel, s in LADDER:
        all_row[slabel] = (sum(1 for n in gold_counts if n > 0) / max(len(gold_counts), 1)
                           if s is None else rows_by.get(s, {}).get(f"recall@{k}"))
    return cat_rows, all_row


def _routing(raw: dict, hits: dict, cases: list[dict], k: int,
             rows_by: dict) -> dict:
    """路由的净收益：两个对照 + 被拦掉词法路的 query 数。

    为什么给两个对照：路由在四档里有两次露面——② 到 ②+路由（融合层面）、
    ③ 到 ④（重排之上）。两个数的故事不一样，合起来看才知道路由的收益是不是
    被重排吃掉了。
    """
    out: dict = {}
    if "hybrid+rerank_noroute" in rows_by and "hybrid+rerank+route" in rows_by:
        out["on_rerank"] = routing_gain(hits["hybrid+rerank_noroute"]["cases"],
                                        hits["hybrid+rerank+route"]["cases"], cases, k)
    if "hybrid" in rows_by and "hybrid_routed" in rows_by:
        out["on_fusion"] = routing_gain(hits["hybrid"]["cases"],
                                        hits["hybrid_routed"]["cases"], cases, k)
    # 词法路被路由拦掉多少条：可解答集里"没有稀有标识符"的 query 占比
    out["distinctive_cases"] = sum(raw["distinctive"]["cases"])
    out["distinctive_adv"] = sum(raw["distinctive"]["adv"])
    return out
