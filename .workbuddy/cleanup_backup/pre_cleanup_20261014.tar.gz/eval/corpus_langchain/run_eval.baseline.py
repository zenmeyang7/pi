"""四档递进 × 两个指标：在外部语料（ai-agent-langchain-main）上跑同一套 query。

和 tests/test_rag.py 的关系：那边评的是 pi 自己的代码库，且会**增量重建**
索引（store.build(ROOT)）；这里评的是外部仓库，索引是事先用
    uv run python scripts/build_index.py --root <仓库> --out .rag_index_langchain
建好的，脚本只读不写 —— 重建会把外部语料的索引毁掉。

四档严格累加，后者 = 前者 + 正好一个组件，档与档之间的差就是那个组件的净贡献：
    ① 切片        AST 切分成 chunk（不检索）
    ② +混合检索    BM25 词法 + bge-m3 向量，RRF 融合
    ③ +重排        cross-encoder 在融合结果上重排
    ④ +路由        只在 query 含稀有标识符时才放行词法路

指标永远是两条，因为只看召回的优化是假的（多捞总能多中）：
    召回率 recall@5          30 条标注了 gold 行区间的可解答 query
    对抗幻觉率              18 条"这个仓库里根本没有答案"的 query，
                            系统有没有把不相干的上下文、以超过拒答线的
                            自信度递上去

    uv run python eval/corpus_langchain/run_eval.py
    uv run python eval/corpus_langchain/run_eval.py --md eval/corpus_langchain/result.md
"""
import argparse
import math
import os
import sys
import time
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

# 必须在 import rag.* 之前：rag.config 是导入时就求值的
from dotenv import load_dotenv

load_dotenv(os.path.join(ROOT, ".env"))

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from adversarial import ADVERSARIAL_CASES                       # noqa: E402
from eval.metrics import (abstention_auc, calibrate_tau, load_cases,  # noqa: E402
                          mrr, ndcg_at_k, recall_at_k, score_hits,
                          vec_index)
from rag.embedder import embed, health_check                    # noqa: E402
from rag.reranker import get_reranker                           # noqa: E402
from rag.retriever import Retriever                             # noqa: E402
from rag.store import IndexStore, normalize                     # noqa: E402

INDEX_DIR = os.path.join(ROOT, ".rag_index_langchain")
CASES = os.path.join(HERE, "cases.jsonl")
K = 5

STAGES = [
    ("① 切片", None),
    ("② +混合检索", "hybrid"),
    ("③ +重排", "hybrid+rerank_noroute"),
    ("④ +路由", "hybrid+rerank+route"),
]
CAT_LABELS = [
    ("function_location", "函数定位"),
    ("class_responsibility", "类职责"),
    ("call_relation", "调用关系"),
    ("semantic", "语义"),
    ("vague_description", "模糊描述"),
]


def _w(s):
    """终端宽度：中日韩字符占两列。f-string 的 {:<14} 按字符数补空格会歪。"""
    return sum(2 if ord(c) > 0x2E80 else 1 for c in s)


def _pad(s, width, right=False):
    gap = " " * max(width - _w(s), 0)
    return gap + s if right else s + gap


def _short(path):
    """project_01_rag_agent/agent.py -> p01/agent.py

    30 个项目里几乎每个都有 agent.py，只打文件名的话漏检清单全是
    "agent.py:124"，根本看不出是哪个项目掉的。
    """
    parts = path.split("/")
    if len(parts) > 1 and parts[0].startswith("project_"):
        return "p" + parts[0][len("project_"):][:2] + "/" + "/".join(parts[1:])
    return path


def is_hit(meta, case):
    if meta["path"] != case["path"]:
        return False
    g0, g1 = case["lines"]
    r0, r1 = meta.get("start_line", 0), meta.get("end_line", 0)
    return r0 <= g1 and g0 <= r1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default=INDEX_DIR)
    ap.add_argument("--cases", default=CASES)
    ap.add_argument("--k", type=int, default=K)
    ap.add_argument("--md", default=os.path.join(HERE, "result.md"))
    args = ap.parse_args()
    k = args.k

    ok, msg = health_check()
    if not ok:
        print(f"[eval] 需要 Ollama：{msg}")
        return 1

    cases = load_cases(args.cases)
    adv = ADVERSARIAL_CASES

    store = IndexStore(os.path.abspath(args.index)).load()
    if not store.chunks:
        print(f"[eval] 索引为空：{args.index}")
        return 1
    print(f"[eval] 索引 {len(store.chunks)} 个 chunk；"
          f"可解答 {len(cases)} 条 + 对抗 {len(adv)} 条；top-{k}")

    reranker = get_reranker(warn=lambda *_: None)
    print(f"[eval] reranker = {reranker.name}")
    if reranker.name != "cross-encoder":
        print("[eval] 没有可用的 cross-encoder，③④ 两档不出数"
              "（降级成纯 RRF 的结果不能算成重排的效果）")

    # 两套 query 一起批量 embedding：逐条调 Ollama 每次约 2s
    queries = [c["query"] for c in cases] + [a["query"] for a in adv]
    t0 = time.perf_counter()
    vecs = embed(queries)
    cache = {q: normalize(v) for q, v in zip(queries, vecs)}
    print(f"[eval] embed {len(queries)} 条 query，{time.perf_counter() - t0:.1f}s")
    vby = vec_index(store)
    retriever = Retriever(store, reranker, embed_fn=lambda q: cache[q])

    strategies = ["lexical", "vector", "hybrid", "hybrid_routed"]
    if reranker.name == "cross-encoder":
        strategies += ["hybrid+rerank_noroute", "hybrid+rerank+route"]

    hits, adv_hits, lat = {}, {}, {}
    for s in strategies:
        lat[s], hits[s], adv_hits[s] = [], [], []
        for c in cases:
            t = time.perf_counter()
            hits[s].append(retriever.retrieve_by_strategy(c["query"], s, k=k))
            lat[s].append((time.perf_counter() - t) * 1000)
        for a in adv:
            adv_hits[s].append(retriever.retrieve_by_strategy(a["query"], s, k=k))
        print(f"[eval] {s:24s} done  p50={sorted(lat[s])[len(lat[s]) // 2]:.0f}ms",
              flush=True)

    # 拒答线：可解答集全库最高余弦的 p10 —— 换模型/换语料自动重新标定
    pos_best = [max(math.sumprod(cache[c["query"]], ch["vec"]) for ch in store.chunks)
                for c in cases]
    tau = calibrate_tau(pos_best, q=0.10)

    def _best(hl, qvec, at=None):
        s = score_hits(hl, qvec, vby, at)
        return max(s) if s else 0.0

    def _corpus_top1(qvec):
        ch = max(store.chunks, key=lambda c: math.sumprod(qvec, c["vec"]))
        return [{"id": ch["id"], "text": ch["text"], "meta": ch["meta"]}]

    gold_chunks = [[ch for ch in store.chunks if is_hit(ch["meta"], c)] for c in cases]
    rows_by = {}
    for s in strategies:
        n = len(cases)
        rows_by[s] = {
            f"recall@{k}": sum(recall_at_k(r, c, k) for r, c in zip(hits[s], cases)) / n,
            f"mrr@{k}": sum(mrr(r, c, k) for r, c in zip(hits[s], cases)) / n,
            f"ndcg@{k}": sum(ndcg_at_k(r, c, k) for r, c in zip(hits[s], cases)) / n,
            "p50_ms": sorted(lat[s])[len(lat[s]) // 2],
        }
    if "hybrid+rerank+route" in rows_by:
        rows_by["hybrid+rerank"] = rows_by["hybrid+rerank+route"]

    # ---------------- 四档 × 两指标 ----------------
    stage_rows = []
    for label, s in STAGES:
        if s is not None and s not in rows_by:
            continue
        if s is None:                                   # ① 切片：不检索
            neg1 = [_best(_corpus_top1(cache[a["query"]]), cache[a["query"]], 1)
                    for a in adv]
            negk = neg1
            pos1 = pos_best
            recall = sum(1 for m in gold_chunks if m) / max(len(cases), 1)
        else:
            neg1 = [_best(h, cache[a["query"]], 1) for h, a in zip(adv_hits[s], adv)]
            negk = [_best(h, cache[a["query"]], k) for h, a in zip(adv_hits[s], adv)]
            pos1 = [_best(h, cache[c["query"]], 1) for h, c in zip(hits[s], cases)]
            recall = rows_by[s][f"recall@{k}"]
        out1 = [v for v, a in zip(neg1, adv) if a["kind"] == "out_of_scope"]
        near1 = [v for v, a in zip(neg1, adv) if a["kind"] == "near_miss"]
        stage_rows.append({
            "stage": label, "recall": recall,
            "halluc": sum(v >= tau for v in neg1) / max(len(neg1), 1),
            "halluc_out": sum(v >= tau for v in out1) / max(len(out1), 1),
            "halluc_near": sum(v >= tau for v in near1) / max(len(near1), 1),
            "halluc_atk": sum(v >= tau for v in negk) / max(len(negk), 1),
            "auc": abstention_auc(pos1, neg1),
            "neg1": neg1,
        })

    routed_in = [c for c in cases if store.has_distinctive_code_token(c["query"])]

    print(f"\n==== 四档递进：两个指标一起看（语料 = ai-agent-langchain-main）====")
    print(f"拒答线 tau = {tau:.3f}（可解答集全库最高余弦的 p10，随模型/语料自动标定）")
    cols = [("档位", 14), (f"recall@{k}", 10), ("幻觉@1", 9), ("域外", 8),
            ("近义", 8), (f"幻觉@{k}", 9), ("可分性", 8)]
    print("".join(_pad(c, w) for c, w in cols))
    for r in stage_rows:
        print("".join(_pad(f"{v:.3f}" if isinstance(v, float) else v, w) for v, w in
                      zip([r["stage"], r["recall"], r["halluc"], r["halluc_out"],
                           r["halluc_near"], r["halluc_atk"], r["auc"]],
                          [w for _, w in cols])))
    print("（可分性 = P(对抗题自信度 ≥ 可解答题)：0 完美拒答，0.5 分不清）")
    for r in stage_rows:
        bad = [(a["query"], v) for a, v in zip(adv, r["neg1"]) if v >= tau]
        if bad:
            top = "，".join(f"{q[:16]}…({v:.2f})" for q, v in
                            sorted(bad, key=lambda x: -x[1])[:4])
            print(f'    {r["stage"]} 判为幻觉 {len(bad)}/{len(adv)}：{top}')

    # ---------------- 五方向 × 四档 ----------------
    cat_idxs = defaultdict(list)
    for i, c in enumerate(cases):
        cat_idxs[c.get("category", "other")].append(i)
    print(f"\n==== 五方向 × 四档 recall@{k} ====")
    hdr = _pad("方向", 14) + "".join(_pad(lbl, 12) for lbl, _ in STAGES)
    print(hdr)
    print("-" * _w(hdr))
    cat_rows = {}
    for cat_key, cat_label in CAT_LABELS:
        idxs = cat_idxs.get(cat_key, [])
        if not idxs:
            continue
        row = {}
        for slabel, s in STAGES:
            if s is None:
                row[slabel] = 1.0
            elif s in rows_by:
                row[slabel] = sum(recall_at_k(hits[s][i], cases[i], k)
                                  for i in idxs) / len(idxs)
            else:
                row[slabel] = None
        cat_rows[cat_label] = row
        print(_pad(cat_label, 14) +
              "".join(_pad(f"{v:.3f}" if v is not None else "—", 12)
                      for v in row.values()))
    print("-" * _w(hdr))
    all_row = {}
    for slabel, s in STAGES:
        all_row[slabel] = 1.0 if s is None else rows_by.get(s, {}).get(f"recall@{k}")
    print(_pad("全部", 14) +
          "".join(_pad(f"{v:.3f}" if v is not None else "—", 12)
                  for v in all_row.values()))

    # ---------------- 各策略详细 + 漏检 ----------------
    print(f"\n==== 各策略详细 ====")
    dcols = [("strategy", 24), (f"recall@{k}", 10), (f"mrr@{k}", 9),
             (f"ndcg@{k}", 9), ("p50_ms", 10)]
    print("".join(_pad(c, w) for c, w in dcols))
    for s in strategies:
        r = rows_by[s]
        print("".join(_pad(v, w) for v, w in
                      zip([s, f"{r[f'recall@{k}']:.3f}", f"{r[f'mrr@{k}']:.3f}",
                           f"{r[f'ndcg@{k}']:.3f}", f"{r['p50_ms']:.0f}"],
                          [w for _, w in dcols])))
    print("\n==== 漏检明细 ====")
    miss_by = {}
    for s in strategies:
        miss = [f'{_short(c["path"])}:{c["lines"][0]}'
                for c, r in zip(cases, hits[s]) if not any(is_hit(x["meta"], c) for x in r)]
        miss_by[s] = miss
        print(f"    {s:24s} 漏检 {len(miss):2d}/{len(cases)}: {', '.join(miss)}")
    print(f"    路由让词法路发言 {len(routed_in)}/{len(cases)} 条 query")

    # ---------------- markdown ----------------
    if args.md:
        L = [f"# 检索评测：语料 = ai-agent-langchain-main", "",
             "## 环境", "",
             "| 项 | 值 |", "|---|---|",
             f"| 索引 chunk 数 | {len(store.chunks)} |",
             f"| 可解答集 | {len(cases)} 条（五方向各 6 条） |",
             f"| 对抗集 | {len(adv)} 条（out_of_scope 10 + near_miss 8） |",
             "| embedding | bge-m3 (Ollama) |",
             f"| rerank | {reranker.name} |",
             f"| 拒答线 tau | {tau:.3f} |", f"| top-k | {k} |", "",
             "## 四档递进：召回率 + 对抗幻觉率", "",
             "| 档位 | " + " | ".join(c for c, _ in cols[1:]) + " |",
             "|" + "|".join(["---"] * len(cols)) + "|"]
        for r in stage_rows:
            L.append("| {} | {} |".format(r["stage"], " | ".join(
                f"{v:.3f}" for v in [r["recall"], r["halluc"], r["halluc_out"],
                                     r["halluc_near"], r["halluc_atk"], r["auc"]])))
        L += ["", f"## 五方向 × 四档 recall@{k}", "",
              "| 方向 | " + " | ".join(lbl for lbl, _ in STAGES) + " |",
              "|" + "|".join(["---"] * (len(STAGES) + 1)) + "|"]
        for label, row in cat_rows.items():
            L.append(f"| {label} | " + " | ".join(
                f"{v:.3f}" if v is not None else "—" for v in row.values()) + " |")
        L.append("| **全部** | " + " | ".join(
            f"{v:.3f}" if v is not None else "—" for v in all_row.values()) + " |")
        L += ["", "## 各策略详细", "",
              "| strategy | " + " | ".join(c for c, _ in dcols[1:]) + " |",
              "|" + "|".join(["---"] * len(dcols)) + "|"]
        for s in strategies:
            r = rows_by[s]
            L.append(f"| {s} | {r[f'recall@{k}']:.3f} | {r[f'mrr@{k}']:.3f} | "
                     f"{r[f'ndcg@{k}']:.3f} | {r['p50_ms']:.0f} |")
        L += ["", "## 漏检明细", "",
              "路径格式 `p01/agent.py:124` = project_01 的 agent.py 第 124 行起"
              "（30 个项目里几乎每个都有 agent.py，只写文件名会分不清是谁掉的）。", "",
              "| strategy | 漏检 | gold |", "|---|---|---|"]
        for s in strategies:
            L.append(f"| {s} | {len(miss_by[s])}/{len(cases)} | "
                     f"{', '.join(miss_by[s]) or '—'} |")
        L.append(f"\n路由让词法路发言 {len(routed_in)}/{len(cases)} 条 query。")
        with open(args.md, "w", encoding="utf-8") as f:
            f.write("\n".join(L) + "\n")
        print(f"\n报告已写入 {args.md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
