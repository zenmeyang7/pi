"""对抗集（语料 = ai-agent-langchain-main，30 个 LangChain/LangGraph 项目）。

recall 只回答"该找的找没找到"，回答不了另一半：**不该找的时候有没有瞎找**。
分两类，难度差很多，分开报才看得出问题在哪：

    out_of_scope  问这个项目压根没碰过的外部技术栈。词法路零命中，向量路也
                  只能捞到远房亲戚 —— 这类**太好拒绝**，全对说明不了什么；
                  错了则说明拒答线根本没设。
    near_miss     语料里**有**很像的素材，答案却依然不存在：仓库里到处都是
                  错误处理，却没有任何退避重试；有 RBAC 却没有多租户隔离。
                  这才是幻觉的主产区 —— 检索确实捞到了很像的代码，模型顺着
                  就能编出个名字。

must_not 只给 out_of_scope，且**只锁英文专有名词**：
不锁"缓存""限流""监控"这类中文通用词 —— 仓库里有 ops/monitor 类项目，
这些词肯定散落在注释里，锁了只会误报。由 check_set.py 守着：
它们必须在语料里 0 命中，否则那道题是漏检题不是幻觉题。

⚠️ 本文件被 rag/config.py 的 INDEX_IGNORE_FILES 排除出索引：
   对抗题的主题词一旦进语料，检索就能直接命中它，幻觉率会假性变差。
"""

ADVERSARIAL_CASES = [
    # ---- out_of_scope：语料里一个字都没有的外部技术栈 ----
    # 选词踩过两次坑，都记在这：
    #   ① "redis" / "celery" —— 语料里确实没有落地代码，但 project_09 的 README
    #      待办清单里写着"添加 Redis 缓存""支持 Celery"，词法一扫就中。
    #      TODO 也是语料，这类题会静默变成漏检题。
    #   ② "react" —— 这个项目是 **ReAct** 框架，全仓库到处都是，
    #      小写后和前端框架 React 撞车，永远不可能 0 命中。
    # 所以下面每个 must_not 都先在全库 chunk 文本上数过次数，确认是 0。
    {"query": "项目里 Memcached 缓存的过期时间是怎么配的", "kind": "out_of_scope",
     "must_not": ["memcached"]},
    {"query": "Kafka 消费者组的位移是怎么提交的", "kind": "out_of_scope",
     "must_not": ["kafka"]},
    {"query": "gRPC 的双向流是在哪个模块实现的", "kind": "out_of_scope",
     "must_not": ["grpc"]},
    {"query": "Terraform 的 infrastructure 编排脚本放在哪", "kind": "out_of_scope",
     "must_not": ["terraform"]},
    {"query": "前端 Angular 的组件是怎么写的", "kind": "out_of_scope",
     "must_not": ["angular"]},
    {"query": "Nginx 的反向代理规则在哪配置", "kind": "out_of_scope",
     "must_not": ["nginx"]},
    {"query": "Airflow 的 DAG 定时调度在哪定义", "kind": "out_of_scope",
     "must_not": ["airflow"]},
    {"query": "Elasticsearch 的倒排索引是怎么建的", "kind": "out_of_scope",
     "must_not": ["elasticsearch"]},
    {"query": "RabbitMQ 的消息确认机制是怎么做的", "kind": "out_of_scope",
     "must_not": ["rabbitmq"]},
    {"query": "GraphQL 的 schema 定义放在哪个文件", "kind": "out_of_scope",
     "must_not": ["graphql"]},
    {"query": "PostgreSQL 的连接串是在哪个配置文件里写的", "kind": "out_of_scope",
     "must_not": ["postgresql"]},
    {"query": "MongoDB 的集合分片键是怎么选的", "kind": "out_of_scope",
     "must_not": ["mongodb"]},
    {"query": "TensorFlow 的模型推理图在哪加载", "kind": "out_of_scope",
     "must_not": ["tensorflow"]},
    {"query": "PyTorch 的 DataLoader 并行数配的是多少", "kind": "out_of_scope",
     "must_not": ["pytorch"]},
    {"query": "Django 的中间件注册顺序在哪定义", "kind": "out_of_scope",
     "must_not": ["django"]},
    {"query": "Flask 的蓝图是在哪注册的", "kind": "out_of_scope",
     "must_not": ["flask"]},
    {"query": "Cassandra 的一致性级别配的是哪一种", "kind": "out_of_scope",
     "must_not": ["cassandra"]},
    {"query": "Neo4j 的图查询语句写在哪个模块", "kind": "out_of_scope",
     "must_not": ["neo4j"]},
    {"query": "Kibana 的仪表盘配置文件放在哪", "kind": "out_of_scope",
     "must_not": ["kibana"]},
    {"query": "ZooKeeper 的选举逻辑在哪实现", "kind": "out_of_scope",
     "must_not": ["zookeeper"]},
    {"query": "Swagger 的接口文档是怎么自动生成的", "kind": "out_of_scope",
     "must_not": ["swagger"]},
    # ---- near_miss：素材很像，答案没有 ----
    # 仓库里确实有 RBAC / 错误处理 / 会话记忆 / Ollama 模型配置，
    # 所以检索一定捞得到东西，但下面每个问题的答案都不存在。
    # 这一类是幻觉的主产区，难度远高于 out_of_scope，所以条数给到 16。
    {"query": "多租户之间的数据是怎么隔离的", "kind": "near_miss"},
    {"query": "接口的限流和熔断降级是在哪里做的", "kind": "near_miss"},
    {"query": "工具调用失败之后的指数退避重试是怎么写的", "kind": "near_miss"},
    {"query": "用户密码是用什么算法加密存储的", "kind": "near_miss"},
    {"query": "会话历史是怎么增量同步到云端的", "kind": "near_miss"},
    {"query": "模型微调的训练脚本放在哪个目录", "kind": "near_miss"},
    {"query": "分布式任务队列的并发工作线程数怎么调", "kind": "near_miss"},
    {"query": "A/B 实验的分桶逻辑在哪实现", "kind": "near_miss"},
    {"query": "代码沙箱对 CPU 和内存用量的硬性限制在哪设置", "kind": "near_miss"},
    {"query": "权限变更的操作审计日志是写到哪里的", "kind": "near_miss"},
    {"query": "LLM 调用的 token 消耗是怎么统计计费的", "kind": "near_miss"},
    {"query": "向量索引的增量更新和段合并策略是怎么做的", "kind": "near_miss"},
    {"query": "多语言国际化的文案资源文件放在哪", "kind": "near_miss"},
    {"query": "文件上传之后的病毒扫描是在哪一步做的", "kind": "near_miss"},
    {"query": "服务优雅退出时的连接 draining 是怎么处理的", "kind": "near_miss"},
    {"query": "数据库事务的隔离级别配的是哪一种", "kind": "near_miss"},
]
