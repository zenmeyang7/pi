"""报告层：终端表 + markdown + JSON。**只读 Experiment，不自己算指标**。

排版（含中日韩字符宽度）全部集中在这里：终端里 CJK 占两列，f-string 的 {:<14}
按字符数补空格会歪，所以显示宽度得自己算——这类"只是好看"的代码和执行逻辑混在
一起时，最容易在改动中被顺手改坏，分开就没事。

报告的读法（也是这份表为什么长这样）：
    ① Chunk Coverage 是**数据集健康度**，不是检索成绩。它 < 1.0 时后面的 recall
      都在替标注背锅，所以它单独一列、且不参与档位间的比较；
    ②③④ 是累加的四档，档与档的差正好等于那一个组件的净贡献；
    FAR 与 recall 必须一起看——只看 recall 的优化是假的（多捞总能多中）。

⚠️ 与 evaluator 同规矩：顶层 import evaluator（它拉进 eval.metrics -> rag.config，
   而 rag.config 是导入时求值的），所以本模块只能在 run_eval.py 的 load_dotenv
   **之后**被导入。本模块不直接 import rag.*。
"""
from __future__ import annotations

import json

from evaluator import Experiment

CORPUS_NAME = "ai-agent-langchain-main"
DASH = "—"

# 四档里"检索那三档"：档位名 -> 策略名。① 没有策略（它不检索）。
STAGE_STRATEGIES: list[tuple[str, str]] = [
    (label, s) for label, s in
    [("② Hybrid", "hybrid"), ("③ Hybrid+Rerank", "hybrid+rerank_noroute"),
     ("④ Hybrid+Rerank+Route", "hybrid+rerank+route")]
]


# ==================== 排版工具 ====================

def _w(s: str) -> int:
    """终端显示宽度：中日韩字符占两列。"""
    return sum(2 if ord(c) > 0x2E80 else 1 for c in s)


def _pad(s: str, width: int, right: bool = False) -> str:
    gap = " " * max(width - _w(s), 0)
    return gap + s if right else s + gap


def _clip(s: str, width: int) -> str:
    """按显示宽度截断，超宽补省略号。"""
    if _w(s) <= width:
        return s
    out, used = "", 0
    for ch in s:
        cw = 2 if ord(ch) > 0x2E80 else 1
        if used + cw > width - 1:
            break
        out += ch
        used += cw
    return out + "…"


def _table(cols: list[tuple[str, int, bool]], rows: list[list[str]]) -> list[str]:
    """cols: (表头, 宽度, 是否右对齐)。数字列右对齐，人眼才能竖着比大小。"""
    lines = ["".join(_pad(c, w, r) for c, w, r in cols)]
    for row in rows:
        lines.append("".join(_pad(v, w, r) for v, (_, w, r) in zip(row, cols)))
    return lines


def _f(v: float | None, nd: int = 3) -> str:
    return DASH if v is None else f"{v:.{nd}f}"


def _ms(v: float | None) -> str:
    return DASH if v is None else f"{v:.0f}ms"


def _short(key: str) -> str:
    """project_01_rag_agent/agent.py:124 -> p01/agent.py:124

    30 个项目里几乎每个都有 agent.py，只打文件名的话漏检清单全是
    "agent.py:124"，根本看不出是哪个项目掉的。
    """
    parts = key.split("/")
    if len(parts) > 1 and parts[0].startswith("project_"):
        return "p" + parts[0][len("project_"):][:2] + "/" + "/".join(parts[1:])
    return key


def _bad_adv(exp: Experiment, row: dict) -> list[tuple[str, float]]:
    """某一档里被"错误接受"的对抗题（自信度越过 tau），按自信度从高到低。

    FAR 是个比值，光看比例只知道"错了一成"，看不出错的是哪一类——名单才定位得到
    问题（近义题被接受说明边界不严，域外题被接受说明拒答线根本没设）。
    """
    return sorted(((q, v) for q, v in zip(exp.adv_queries, row["neg1"]) if v >= exp.tau),
                  key=lambda x: -x[1])


# ==================== 表体 ====================

def _ladder_table(exp: Experiment) -> list[str]:
    """主表：四档递进。Coverage 只属于 ①，其余档位那一格是 —（不参与比较）。"""
    k = exp.k
    cols = [("档位", 24, False), ("Coverage", 9, True), (f"Recall@{k}", 10, True),
            ("FAR↓", 8, True), ("FAR_域外", 9, True), ("FAR_近义", 9, True),
            ("p50", 8, True), ("p95", 8, True)]
    rows = [[r["stage"], _f(r["coverage"]), _f(r["recall"]), _f(r["far"]),
             _f(r["far_out"]), _f(r["far_near"]), _ms(r["p50_ms"]), _ms(r["p95_ms"])]
            for r in exp.stage_rows]
    return _table(cols, rows)


def _footnotes(exp: Experiment) -> list[str]:
    """口径说明 + 主表装不下的那几个数。数字不藏，但不占成绩位。"""
    k, n = exp.k, exp.counts["n_cases"]
    lines = [
        f"拒答线 tau = {exp.tau:.3f}   "
        f"（= 可解答集全库最高余弦的 p10，换模型/换语料时自动重标定）",
        f"FAR↓ = False Acceptance Rate，越低越好：本来没有答案的题里，"
        f"被递上超过 tau 的上下文的比例",
        f"    FAR@1 只算 top-1（模型第一眼看到的）；"
        f"FAR@{k} 是 top-{k} 里只要有一条越线就算（更严）：",
    ]
    far_k = "   ".join(f'{r["stage"].split()[0]} {_f(r["far_at_k"])}'
                       for r in exp.stage_rows)
    auc = "   ".join(f'{r["stage"].split()[0]} {_f(r["auc"])}' for r in exp.stage_rows)
    lines += [f"      {far_k}",
              f"可分性 = P(对抗题自信度 ≥ 可解答题)：0 完美拒答，0.5 分不清 —— {auc}"]

    base = exp.stage_rows[0]                       # ① 行 = 不做检索的对照组
    lines.append(
        f"无检索基线（不召回，直接把全库最像的 chunk 递上去）："
        f"FAR {_f(base['far'])}（域外 {_f(base['far_out'])} / 近义 {_f(base['far_near'])}）、"
        f"可分性 {_f(base['auc'])}")
    lines.append(
        f"    —— 拿 ②③④ 和这一行比：「低得多」才说明检索真把无关上下文筛掉了；"
        f"与它持平就说明拒答靠的只是阈值，检索没帮上忙")

    cov = exp.coverage
    if cov.get("uncovered"):
        lines.append(f"⚠️ Chunk Coverage {cov['value']:.3f}"
                     f"（{n - len(cov['uncovered'])}/{n}）：gold 标注没落进任何 chunk 的有 "
                     f"{len(cov['uncovered'])} 条 —— {', '.join(cov['uncovered'])}")
        lines.append("    这是「数据集故障」不是检索故障：先修标注，"
                     "否则这些题在每一档都必然漏，横比会让别的方向替它背锅")
    else:
        lines.append(f"Chunk Coverage {cov['value']:.3f}（{n}/{n}）："
                     f"每条 gold 都落在至少一个 chunk 上，后面的 recall 不替标注背锅")

    # n 不大时 p95 就是"第 58 个样本"这种单点，容易被当成 SLA 读
    lines.append(f"注：延迟只统计 {n} 条可解答 query（不混对抗集，否则两次跑的"
                 f"分母就变了）；n={n} 时 p95 落在第 {int(0.95 * (n - 1)) + 1} 个样本，"
                 f"是尾部信号而不是 SLA")
    return lines


def _category_table(exp: Experiment) -> list[str]:
    """五方向 × 四档。① 那列是**该方向的覆盖率**，不是 recall。"""
    k = exp.k
    labels = [lbl for lbl, _ in exp.ladder]
    heads = [("方向", 16, False)] + [
        (f"① Coverage" if s is None else lbl.split(" ", 1)[0] + f" Recall@{k}", 13, True)
        for lbl, s in exp.ladder]
    rows = [[label] + [_f(v) for v in row.values()] for label, row in exp.cat_rows.items()]
    rows.append(["全部"] + [_f(v) for v in exp.all_row.values()])
    return _table(heads, rows)


def _strategy_table(exp: Experiment) -> list[str]:
    k = exp.k
    cols = [("strategy", 24, False), (f"recall@{k}", 10, True), (f"mrr@{k}", 9, True),
            (f"ndcg@{k}", 9, True), ("p50", 8, True), ("p95", 8, True)]
    rows = [[s, _f(r[f"recall@{k}"]), _f(r[f"mrr@{k}"]), _f(r[f"ndcg@{k}"]),
             _ms(r["p50_ms"]), _ms(r["p95_ms"])] for s, r in exp.rows_by.items()]
    return _table(cols, rows)


def _routing_blocks(exp: Experiment) -> list[tuple[str | None, list[str]]]:
    """Routing Gain：[（组标题或 None, [明细行...]）]，两个渲染器共用一份结构。

    只报总数是不够的："+0.10" 可能是救回 8 条、也可能是救回 8 条同时弄丢 4 条。
    路由是个硬开关（没稀有标识符就整条关掉词法路），每道题只有三种结果，
    所以必须把救回和弄丢分开列。
    """
    n, n_adv = exp.counts["n_cases"], exp.counts["n_adv"]
    blocks: list[tuple[str | None, list[str]]] = []
    for key, title in [("on_rerank", "④ − ③   重排之上的路由净贡献"),
                       ("on_fusion", "②+路由 − ②   融合层面的路由贡献")]:
        g = exp.routing.get(key)
        if not g:
            continue
        # 增益为负时也要能一眼看见：gain 带符号打印
        details = [f"before {_f(g['before'])}   after {_f(g['after'])}   "
                   f"gain {g['gain']:+.3f}"
                   f"（救回 {len(g['gained'])} 条 / 弄丢 {len(g['lost'])} 条）"]
        for tag, idxs in [("救回", g["gained"]), ("弄丢", g["lost"])]:
            if idxs:
                details.append(f"{tag}：" + "，".join(
                    _short(exp.case_keys[i]) for i in idxs))
        blocks.append((title, details))
    blocks.append((None, [
        f"被路由拦掉词法路的 query：可解答 "
        f"{n - exp.routing['distinctive_cases']}/{n}，"
        f"对抗 {n_adv - exp.routing['distinctive_adv']}/{n_adv}"
        f"（其余 query 含稀有标识符，词法路照走）",
        "—— 路由的价值就在这两行：省下的词法路有没有换回召回，"
        "以及它拦住的是不是本来也捞不到东西的题"]))
    return blocks


def _miss_rows(exp: Experiment) -> list[tuple[int, str, str, list[bool]]]:
    """逐题：②③④ 各命中与否。只留至少漏过一次的题（全中的题看它没意义）。"""
    stages = [(label, s) for label, s in STAGE_STRATEGIES if s in exp.hit_flags]
    out = []
    for i in range(exp.counts["n_cases"]):
        flags = [exp.hit_flags[s][i] for _, s in stages]
        if not all(flags):
            out.append((i, exp.case_queries[i], exp.case_keys[i], flags))
    return out


def _miss_matrix(exp: Experiment, clip: int | None) -> tuple[list[str], list[str]]:
    """返回 (矩阵, 汇总)。两个渲染器排版不同，所以分开给。"""
    stages = [(label, s) for label, s in STAGE_STRATEGIES if s in exp.hit_flags]
    if not stages:
        return ["（没有可用的检索档位，③④ 缺 cross-encoder）"], []
    names = [label.split(" ", 1)[0] for label, _ in stages]
    rows = _miss_rows(exp)

    if clip is None:                      # markdown：不截断，全文可检索
        table = ["| 问的什么 | gold 位置 | " + " | ".join(names) + " |",
                 "|---|---|" + "|".join(["---"] * len(names)) + "|"]
        for _, q, key, flags in rows:
            table.append(f"| {q} | `{_short(key)}` | " +
                         " | ".join("✓" if f else "✗" for f in flags) + " |")
        if not rows:
            table.append("| _无漏检_ | |" + " |" * len(names))
    else:
        cols = [("问的什么", clip, False), ("gold 位置", 26, False)] + \
               [(n, 4, True) for n in names]
        table = _table(cols, [[_clip(q, clip), _short(key)] +
                              ["✓" if f else "✗" for f in flags]
                              for _, q, key, flags in rows])
        if not rows:
            table.append("(②③④ 全部命中，没有漏检)")

    n = exp.counts["n_cases"]
    summary = ["汇总：" + "，".join(
        f"{label.split()[0]} 漏 {sum(1 for flag in exp.hit_flags[s] if not flag)}/{n}"
        for label, s in stages)]
    if len(stages) >= 2:
        first, last = stages[0][1], stages[-1][1]
        saved_by_last = sum(1 for i in range(n)
                            if not exp.hit_flags[first][i] and exp.hit_flags[last][i])
        all_missed = sum(1 for i in range(n)
                         if not any(exp.hit_flags[s][i] for _, s in stages))
        summary.append(f"全档皆漏 {all_missed} 条（要么标注有问题，要么 gold 在语料里"
                       f"根本没有对应实现，两种都得先去查标注）；"
                       f"靠最后一档才捞回 {saved_by_last} 条")
    return table, summary


# ==================== 组装 ====================

def _env_lines(exp: Experiment) -> list[str]:
    c = exp.counts
    cats = "、".join(f"{label} {n}" for label, n in c["cats"].items())
    return [
        f"索引 {exp.meta['chunk_count']} chunk｜可解答 {c['n_cases']} 条（{cats}）"
        f"｜对抗 {c['n_adv']} 条（out_of_scope {c['n_out']} + near_miss {c['n_near']}）"
        f"｜top-{exp.k}",
        f"rerank = {exp.meta['reranker_name']}｜embedding = "
        f"{exp.meta.get('embed_model') or DASH}｜采集于 {exp.meta['built_at']}",
    ]


def print_report(exp: Experiment) -> None:
    """把一整份报告打到终端。顺序：环境 -> 四档 -> 五方向 -> 路由 -> 各策略 -> 漏检。"""
    k = exp.k
    print(f"\n==== RAG Evaluation on {CORPUS_NAME} ====")
    print("\n".join(_env_lines(exp)))

    print("\n---- 四档递进：召回 + 拒答，两个指标一起看 ----")
    print("\n".join(_ladder_table(exp)))
    for r in exp.stage_rows:
        bad = _bad_adv(exp, r)
        if bad:
            top = "，".join(f"{q[:16]}…({v:.2f})" for q, v in bad[:4])
            more = f" 等 {len(bad)} 条" if len(bad) > 4 else ""
            print(f'    {r["stage"]} 错误接受 {len(bad)}/{exp.counts["n_adv"]}：'
                  f"{top}{more}")
    print("\n".join(_footnotes(exp)))

    print(f"\n---- 五方向 × 四档（① 列是覆盖率，②③④ 是 recall@{k}）----")
    print("\n".join(_category_table(exp)))

    print("\n---- Routing Gain ----")
    for title, details in _routing_blocks(exp):
        if title:
            print(f"    {title}")
        print("\n".join(f"        {d}" for d in details))

    print("\n---- 各策略详细 ----")
    print("\n".join(_strategy_table(exp)))

    print("\n---- 漏检矩阵（②③④ 全中的题不列）----")
    table, summary = _miss_matrix(exp, clip=44)
    print("\n".join(table))
    print("\n".join(f"    {ln}" for ln in summary))


def _markdown(exp: Experiment) -> list[str]:
    k, c = exp.k, exp.counts
    labels = [lbl for lbl, _ in exp.ladder]

    L = [f"# RAG Evaluation on {CORPUS_NAME}", "",
         "## 环境", "",
         "| 项 | 值 |", "|---|---|",
         f"| 索引 chunk 数 | {exp.meta['chunk_count']} |",
         # 条数一律现算：写死的说明已经错过一次（"五方向各 6 条"对上的是 30 条时代，
         # 实际 61 条），数字与说明不一致比数字过期更难发现
         f"| 可解答集 | {c['n_cases']} 条（{'、'.join(f'{label} {n}' for label, n in c['cats'].items())}） |",
         f"| 对抗集 | {c['n_adv']} 条（out_of_scope {c['n_out']} + near_miss {c['n_near']}） |",
         f"| embedding | {exp.meta.get('embed_model') or DASH} (Ollama) |",
         f"| rerank | {exp.meta['reranker_name']} |",
         f"| 拒答线 tau | {exp.tau:.3f} |",
         f"| top-k | {k} |",
         f"| 结果采集时间 | {exp.meta['built_at']} |", "",
         "## 四档递进：召回 + 拒答", "",
         "四档严格累加，后者 = 前者 + 正好一个组件，档与档之差就是那个组件的净贡献。",
         "① 不检索，它的数字是 **Chunk Coverage**（数据集健康度），不与其余档比较。", "",
         f"| 档位 | Coverage | Recall@{k} | FAR↓ | FAR_域外 | FAR_近义 | p50 | p95 |",
         "|---|---|---|---|---|---|---|---|"]
    for r in exp.stage_rows:
        L.append(f"| {r['stage']} | {_f(r['coverage'])} | {_f(r['recall'])} | "
                 f"{_f(r['far'])} | {_f(r['far_out'])} | {_f(r['far_near'])} | "
                 f"{_ms(r['p50_ms'])} | {_ms(r['p95_ms'])} |")

    L += ["", "**口径**", ""]
    for ln in _footnotes(exp):
        # 续行（缩进 4 空格）并进上一条，别在 markdown 里变成代码块
        if ln.startswith("    ") and L[-1].startswith("- "):
            L[-1] += " " + ln.strip()
        else:
            L.append(f"- {ln}")

    cat_heads = ["① Coverage" if s is None else f"{lbl} Recall@{k}"
                 for lbl, s in exp.ladder]
    L += ["", f"## 五方向 × 四档", "",
          "| 方向 | " + " | ".join(cat_heads) + " |",
          "|" + "|".join(["---"] * (len(cat_heads) + 1)) + "|"]
    for label, row in exp.cat_rows.items():
        L.append(f"| {label} | " + " | ".join(_f(v) for v in row.values()) + " |")
    L.append("| **全部** | " + " | ".join(_f(v) for v in exp.all_row.values()) + " |")

    L += ["", "## Routing Gain", "",
          "路由是硬开关（query 里没有稀有标识符就整条关掉词法路），"
          "所以每道题只有三种结果，救回与弄丢必须分开看。", ""]
    for title, details in _routing_blocks(exp):
        if title:
            L += ["", f"**{title.strip()}**"]
        L += [f"- {d}" for d in details]

    L += ["", "## 各策略详细", "",
          f"| strategy | recall@{k} | mrr@{k} | ndcg@{k} | p50 | p95 |",
          "|---|---|---|---|---|---|"]
    for s, r in exp.rows_by.items():
        L.append(f"| {s} | {_f(r[f'recall@{k}'])} | {_f(r[f'mrr@{k}'])} | "
                 f"{_f(r[f'ndcg@{k}'])} | {_ms(r['p50_ms'])} | {_ms(r['p95_ms'])} |")

    L += ["", "## 漏检矩阵", "",
          "`✗` = 该档漏这条。路径格式 `p01/agent.py:124` = project_01 的 agent.py "
          "第 124 行起（30 个项目里几乎每个都有 agent.py，只写文件名会分不清是谁掉的）。", ""]
    table, summary = _miss_matrix(exp, clip=None)
    L += table
    L += [""] + summary
    return L


def write_markdown(exp: Experiment, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(_markdown(exp)) + "\n")


def write_json(exp: Experiment, path: str) -> None:
    """机器可读的那份：以后改了什么、数字动了多少，可以直接 diff 两个 json。"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(exp.to_dict(), f, ensure_ascii=False, indent=1)
        f.write("\n")
