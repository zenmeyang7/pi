"""四档递进 × 两个指标：在外部语料（ai-agent-langchain-main）上跑同一套 query。

和 tests/test_rag.py 的关系：那边评的是 pi 自己的代码库，且会**增量重建**
索引（store.build(ROOT)）；这里评的是外部仓库，索引是事先用
    uv run python scripts/build_index.py --root <仓库> --out .rag_index_langchain
建好的，脚本只读不写 —— 重建会把外部语料的索引毁掉。

四档严格累加，后者 = 前者 + 正好一个组件，档与档之间的差就是那个组件的净贡献：
    ① 切片        AST 切分成 chunk（不检索）
    ② +混合检索    BM25 词法 + bge-m3 向量，RRF 融合
    ③ +重排        cross-encoder 在融合结果上重排
    ④ +路由        只在 query 含稀有标识符时才放行词法路

指标永远是两条，因为只看召回的优化是假的（多捞总能多中）：
    召回率 recall@5          61 条标注了 gold 行区间的可解答 query
    对抗幻觉率 FAR           37 条"这个仓库里根本没有答案"的 query，
                            系统有没有把不相干的上下文、以超过拒答线的
                            自信度递上去（并按 out_of_scope / near_miss 拆开）

本文件只做三件事：解析参数、初始化、把执行层与报告层接起来。
指标怎么算看 evaluator.py，报告长什么样看 reporter.py。

    uv run python eval/corpus_langchain/run_eval.py
    uv run python eval/corpus_langchain/run_eval.py --md eval/corpus_langchain/result.md
    # 一次全量跑要重排 196 次（分钟级），把原始结果冻下来之后可以秒级复算：
    uv run python eval/corpus_langchain/run_eval.py --dump-raw raw_hits.json
    uv run python eval/corpus_langchain/run_eval.py --from-raw raw_hits.json --json out.json
    # 当门用（CI / 提交前自测）：指标不达标退出码非 0
    uv run python eval/corpus_langchain/run_eval.py --from-raw raw_hits.json \
        --min-recall 0.70 --max-far 0.10

退出码（CI 靠它判断，所以各码含义不重叠）：
    0  正常
    1  环境/索引/数据集故障：Ollama 不在、索引为空或读不出、夹具与当前
       评测集对不上、gold 标注存在未覆盖（分数不可信，先修数据）
    2  阈值不达标：--min-recall / --max-far 没过。**分数是好的，只是不够好**，
       和 1 分开，CI 里才分得清"机器坏了"和"没达标"
    3  参数写错（argparse 默认也是 2，这里挪到 3，避免和阈值门撞码）
"""
import argparse
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

# 必须在 import rag.* 之前：rag.config 是导入时就求值的
from dotenv import load_dotenv

load_dotenv(os.path.join(ROOT, ".env"))

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from adversarial import ADVERSARIAL_CASES                        
from evaluator import (Experiment, build_experiment, check_raw,   
                       collect_raw, dump_raw, load_raw)
from eval.metrics import STRATEGIES, latency_stats, load_cases     
from rag import config                                           
from rag.embedder import embed, health_check                      
from rag.reranker import get_reranker                             
from rag.retriever import Retriever                               
from rag.store import IndexStore, normalize                       
import reporter                                                   

INDEX_DIR = os.path.join(ROOT, ".rag_index_langchain")
CASES = os.path.join(HERE, "cases.jsonl")
K = 5


class _Parser(argparse.ArgumentParser):
    """参数错误走退出码 3：argparse 默认的 2 被阈值门占着，撞码会让 CI 分不清
    "命令写错了"和"指标没达标"。"""

    def error(self, message):
        self.print_usage(sys.stderr)
        print(f"{self.prog}: 参数错误：{message}", file=sys.stderr)
        raise SystemExit(3)


def _strategy_list(text: str) -> list[str]:
    """--strategies 的值：逗号分隔，名字必须存在。

    名字写错就报错而不是静默忽略——"少跑了一档"和"跑出来没有那一档"在报告里
    长得一模一样，静默忽略会让人以为那档本来就没有。
    """
    names = [s.strip() for s in text.split(",") if s.strip()]
    unknown = [s for s in names if s not in STRATEGIES]
    if unknown:
        raise argparse.ArgumentTypeError(
            f"不认识的策略 {', '.join(unknown)}；可选：{', '.join(STRATEGIES)}")
    return names


def _parse_args():
    ap = _Parser(description=__doc__.splitlines()[0])
    ap.add_argument("--index", default=INDEX_DIR)
    ap.add_argument("--cases", default=CASES)
    ap.add_argument("--k", type=int, default=K)
    ap.add_argument("--md", default=os.path.join(HERE, "result.md"))
    ap.add_argument("--json", default=None, metavar="PATH",
                    help="结构化结果（含元数据与全部指标），便于留档/对比历史")
    ap.add_argument("--dump-raw", default=None, metavar="PATH",
                    help="把原始检索结果（含余弦与延迟）冻成夹具；"
                         "之后可 --from-raw 秒级复算，不用再跑一次检索")
    ap.add_argument("--from-raw", default=None, metavar="PATH",
                    help="不跑检索，直接从夹具复算：离线、秒级、可重复")
    ap.add_argument("--strategies", type=_strategy_list, default=None, metavar="A,B",
                    help=f"只跑这几个策略（逗号分隔）。可选：{', '.join(STRATEGIES)}"
                         "。迭代期提速用；缺了某档它会在报告里显示为未测，不会拿别的"
                         "策略顶替")
    ap.add_argument("--min-recall", type=float, default=None, metavar="R",
                    help="最后一档（完整管线）的 recall@k 低于此值则退出码 2")
    ap.add_argument("--max-far", type=float, default=None, metavar="F",
                    help="任一二三四档的 FAR 高于此值则退出码 2")
    ap.add_argument("--allow-uncovered", action="store_true",
                    help="gold 标注有未覆盖时只告警不失败（修标注期间用的临时开关）")
    return ap.parse_args()


def _strategies_from_raw(want: list[str] | None, recorded: list[str],
                         path: str) -> list[str]:
    """from-raw 时本次要评的策略。默认用夹具录下的（它记得当时跑了哪几档）。

    --strategies 只能**收窄，不能扩**：夹具里没有的策略就是当时没跑，这里补不出来。
    要它就得重跑一次 live —— 报一个跑不出来的策略是错，静默忽略更是错。
    """
    if not want:
        return list(recorded)
    missing = [s for s in want if s not in recorded]
    if missing:
        print(f"[eval] 夹具 {path} 里没有这些策略：{', '.join(missing)}\n"
              f"       （它记录的是：{', '.join(recorded)}）—— 补不上，得重新跑一次 live")
        raise SystemExit(3)
    picked = set(want)
    return [s for s in recorded if s in picked]      # 保持夹具里的顺序


def _gate(exp: Experiment, min_recall: float | None,
          max_far: float | None) -> list[str]:
    """阈值门：返回不达标项（空 = 通过）。

    读的是报告里同一张表的同一个数（都来自 Experiment），所以不会出现
    "报告印 0.754、CI 说没到 0.75"这种自相矛盾。
    ① 档不参与：它不检索，拿覆盖率去顶 recall、拿全库 top-1 去顶 FAR 都会
    把"数据集健康度"算成"管线成绩"。
    """
    bad: list[str] = []
    if min_recall is not None:
        last = exp.stage_rows[-1]           # 最后一档 = 完整管线（累加到底）
        got = last["recall"]
        if got is None or got < min_recall:
            shown = "—" if got is None else f"{got:.3f}"
            bad.append(f'{last["stage"]} recall@{exp.k} = {shown} '
                       f'< --min-recall {min_recall:.3f}')
    if max_far is not None:
        for r in exp.stage_rows:
            if r["strategy"] is None:
                continue
            if r["far"] > max_far:
                bad.append(f'{r["stage"]} FAR = {r["far"]:.3f} > '
                           f'--max-far {max_far:.3f}')
    return bad


def _progress(strategy, latencies):
    print(f"[eval] {strategy:24s} done  "
          f"p50={latency_stats(latencies)['p50_ms']:.0f}ms", flush=True)


def _run_live(args, cases, adv, k):
    """真跑一遍检索：健康检查 -> 索引（只 load，不 build）-> 批量 embedding -> 逐策略检索。"""
    ok, msg = health_check()
    if not ok:
        print(f"[eval] 需要 Ollama：{msg}")
        return None
    store = IndexStore(os.path.abspath(args.index)).load()
    if not store.chunks:
        print(f"[eval] 索引为空：{args.index}")
        return None
    print(f"[eval] 索引 {len(store.chunks)} 个 chunk；"
          f"可解答 {len(cases)} 条 + 对抗 {len(adv)} 条；top-{k}")

    reranker = get_reranker(warn=lambda *_: None)
    print(f"[eval] reranker = {reranker.name}")
    if reranker.name != "cross-encoder":
        print("[eval] 没有可用的 cross-encoder，③④ 两档不出数"
              "（降级成纯 RRF 的结果不能算成重排的效果）")

    # 两套 query 一起批量 embedding：逐条调 Ollama 每次约 2s
    queries = [c["query"] for c in cases] + [a["query"] for a in adv]
    t0 = time.perf_counter()
    vectors = {q: normalize(v) for q, v in zip(queries, embed(queries))}
    print(f"[eval] embed {len(queries)} 条 query，{time.perf_counter() - t0:.1f}s")

    retriever = Retriever(store, reranker, embed_fn=vectors.__getitem__)
    # 没有 cross-encoder 时把重排两档直接摘掉：降级成纯 RRF 的结果不能算成
    # "重排档的成绩"，宁可不出数（摘掉后它们在报告里显示为未测）
    want = args.strategies or STRATEGIES
    strategies = [s for s in want
                  if reranker.name == "cross-encoder" or not s.startswith("hybrid+rerank")]
    if len(strategies) < len(STRATEGIES):
        print(f"[eval] 本次只跑 {len(strategies)}/{len(STRATEGIES)} 个策略："
              f"{', '.join(strategies)}（跑得少不等于跑得差，别拿这份对比全量）")
    raw = collect_raw(retriever, store, cases, adv, strategies, vectors, k,
                      embed_model=config.EMBED_MODEL, on_strategy_done=_progress)
    if args.dump_raw:
        dump_raw(raw, args.dump_raw)
        print(f"[eval] 原始结果已冻到 {args.dump_raw}"
              f"（之后 --from-raw 秒级复算）")
    return raw


def main():
    args = _parse_args()
    k = args.k
    cases = load_cases(args.cases)
    adv = ADVERSARIAL_CASES

    if args.from_raw:
        # 离线复算：不连 Ollama、不连重排。改报告、查口径、回归验证都走这条
        raw = load_raw(args.from_raw)
        problems = check_raw(raw, cases, adv, k)
        if problems:
            print(f"[eval] 夹具 {args.from_raw} 与当前评测集对不上：")
            for p in problems:
                print(f"       - {p}")
            return 1
        print(f"[eval] 复算夹具 {args.from_raw}"
              f"（采集于 {raw['meta']['built_at']}，rerank={raw['meta']['reranker_name']}）")
        strategies = _strategies_from_raw(args.strategies, raw["meta"]["strategies"],
                                          args.from_raw)
        if len(strategies) < len(STRATEGIES):
            print(f"[eval] 本次只评 {len(strategies)}/{len(STRATEGIES)} 个策略："
                  f"{', '.join(strategies)}")
        exp = build_experiment(raw, cases, adv, k, strategies=strategies)
    else:
        raw = _run_live(args, cases, adv, k)
        if raw is None:
            return 1
        exp = build_experiment(raw, cases, adv, k,
                               strategies=raw["meta"]["strategies"])

    reporter.print_report(exp)
    if exp.dropped:
        print(f"    未测到的档位：{', '.join(exp.dropped)}（本次没跑那几个策略，"
              f"或缺 cross-encoder）")
    if args.md:
        reporter.write_markdown(exp, args.md)
        print(f"\n报告已写入 {args.md}")
    if args.json:
        reporter.write_json(exp, args.json)
        print(f"结构化结果已写入 {args.json}")

    # 数据集故障优先于阈值：标注没覆盖到的题在每一档都必然漏，此时"没达标"
    # 是数据的问题，先修数据（与 check_set.py 的 ① 门同义）
    if exp.coverage["uncovered"]:
        if args.allow_uncovered:
            print(f"[eval] 注意：{len(exp.coverage['uncovered'])} 条 gold 没有被任何 chunk "
                  f"覆盖，recall 偏低的锅不全在检索（--allow-uncovered 已放行）")
        else:
            print(f"[eval] 数据集故障：{len(exp.coverage['uncovered'])} 条 gold 没有被任何 "
                  f"chunk 覆盖，指标不可信；先修标注，或加 --allow-uncovered 临时放行")
            return 1

    bad = _gate(exp, args.min_recall, args.max_far)
    if bad:
        print("[eval] 阈值不达标：")
        for b in bad:
            print(f"       - {b}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
