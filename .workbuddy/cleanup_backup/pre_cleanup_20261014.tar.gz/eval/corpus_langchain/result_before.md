# 检索评测：语料 = ai-agent-langchain-main

## 环境

| 项 | 值 |
|---|---|
| 索引 chunk 数 | 1205 |
| 可解答集 | 30 条（五方向各 6 条） |
| 对抗集 | 18 条（out_of_scope 10 + near_miss 8） |
| embedding | bge-m3 (Ollama) |
| rerank | cross-encoder |
| 拒答线 tau | 0.576 |
| top-k | 5 |

## 四档递进：召回率 + 对抗幻觉率

| 档位 | recall@5 | 幻觉@1 | 域外 | 近义 | 幻觉@5 | 可分性 |
|---|---|---|---|---|---|---|
| ① 切片 | 1.000 | 0.167 | 0.200 | 0.125 | 0.167 | 0.054 |
| ② +混合检索 | 0.567 | 0.056 | 0.000 | 0.125 | 0.167 | 0.126 |
| ③ +重排 | 0.667 | 0.000 | 0.000 | 0.000 | 0.056 | 0.074 |
| ④ +路由 | 0.667 | 0.000 | 0.000 | 0.000 | 0.111 | 0.044 |

## 五方向 × 四档 recall@5

| 方向 | ① 切片 | ② +混合检索 | ③ +重排 | ④ +路由 |
|---|---|---|---|---|
| 函数定位 | 1.000 | 1.000 | 1.000 | 1.000 |
| 类职责 | 1.000 | 0.833 | 0.833 | 0.833 |
| 调用关系 | 1.000 | 0.833 | 0.833 | 0.833 |
| 语义 | 1.000 | 0.000 | 0.667 | 0.667 |
| 模糊描述 | 1.000 | 0.167 | 0.000 | 0.000 |
| **全部** | 1.000 | 0.567 | 0.667 | 0.667 |

## 各策略详细

| strategy | recall@5 | mrr@5 | ndcg@5 | p50_ms |
|---|---|---|---|---|
| lexical | 0.433 | 0.341 | 0.363 | 1 |
| vector | 0.700 | 0.558 | 0.593 | 29 |
| hybrid | 0.567 | 0.464 | 0.490 | 29 |
| hybrid_routed | 0.700 | 0.532 | 0.574 | 29 |
| hybrid+rerank_noroute | 0.667 | 0.515 | 0.553 | 2975 |
| hybrid+rerank+route | 0.667 | 0.514 | 0.552 | 2874 |

## 漏检明细

路径格式 `p01/agent.py:124` = project_01 的 agent.py 第 124 行起（30 个项目里几乎每个都有 agent.py，只写文件名会分不清是谁掉的）。

| strategy | 漏检 | gold |
|---|---|---|
| lexical | 17/30 | p01/agent.py:124, p02/agent.py:102, p02/tools/file_tool.py:11, p02/memory.py:95, p03/config.py:11, p01/tools/retriever.py:209, p01/agent.py:102, p02/memory.py:116, p03/agent.py:159, p01/tools/retriever.py:67, p02/agent.py:59, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176 |
| vector | 9/30 | p03/config.py:11, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224 |
| hybrid | 13/30 | p03/config.py:11, p02/agent.py:102, p01/tools/retriever.py:209, p01/agent.py:102, p02/memory.py:116, p03/agent.py:159, p01/tools/retriever.py:67, p02/agent.py:59, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224 |
| hybrid_routed | 9/30 | p03/config.py:11, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224 |
| hybrid+rerank_noroute | 10/30 | p03/config.py:11, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176 |
| hybrid+rerank+route | 10/30 | p03/config.py:11, p02/agent.py:102, p03/agent.py:159, p01/tools/retriever.py:67, p01/agent.py:47, p03/agent.py:122, p02/agent.py:287, p02/agent.py:174, p04/agent.py:224, p04/agent.py:176 |

路由让词法路发言 18/30 条 query。
