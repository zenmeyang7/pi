"""一次性辅助脚本：抽取语料的符号表，供人工标注 gold 用。

不是评测链路的一部分 —— 标注完就可以不管了。留着是为了让 gold 的来源
可复查：每条 case 的行区间都能在这份输出里对上一个真实存在的定义。

    uv run python eval/corpus_langchain/dump_symbols.py
"""
import ast
import os
import sys

CORPUS = r"C:/Users/zheme/Desktop/ai-agent-langchain-main"


def walk(top):
    for root, dirs, files in os.walk(top):
        dirs[:] = [d for d in dirs
                   if d not in {".git", "__pycache__", "node_modules", ".venv"}]
        for fn in sorted(files):
            if fn.endswith(".py"):
                yield os.path.join(root, fn)


def main():
    out = []
    for path in walk(CORPUS):
        rel = os.path.relpath(path, CORPUS).replace("\\", "/")
        try:
            src = open(path, encoding="utf-8").read()
            tree = ast.parse(src)
        except Exception as e:
            out.append(f"### {rel}\n  (parse fail: {e})")
            continue
        lines = src.splitlines()
        rows = []
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                                 ast.ClassDef)):
                doc = ast.get_docstring(node) or ""
                end = getattr(node, "end_lineno", node.lineno)
                rows.append((node.lineno, end, type(node).__name__,
                             node.name, doc.split("\n")[0][:70]))
        if not rows:
            continue
        out.append(f"### {rel}")
        for ln0, ln1, kind, name, doc in rows:
            tag = "C" if kind == "ClassDef" else "F"
            out.append(f"  [{tag}] {ln0:4d}-{ln1:4d} {name}"
                       + (f"  | {doc}" if doc else ""))

    print("\n".join(out))
    print(f"\n# 文件数/符号数统计见 stderr", file=sys.stderr)


if __name__ == "__main__":
    main()
