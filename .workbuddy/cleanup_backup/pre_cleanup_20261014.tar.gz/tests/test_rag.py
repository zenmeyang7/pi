"""检索链路的验证：不依赖服务的单元测试（分词 / BM25 / RRF / AST 切片）
+ 一套自我评测集（切片 → 混合检索 → 重排 → 路由，逐档跑同一套 query）。
"""
import os
import time

# 必须在 import rag.* 之前跑：rag.config 是**导入时**就求值的，
# 晚一步加载，OLLAMA_BASE_URL / RAG_RERANK_ENABLED 拿到的还是空值。
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, ".env"))

import pytest                                                    # noqa: E402

from rag.chunker import chunk_file                               # noqa: E402
from rag.store import BM25, _TOKEN_RE, rrf, tokenize             # noqa: E402

from eval.adversarial import ADVERSARIAL_CASES                   # noqa: E402
from eval.generation import (REFUSAL, ResponseCache, build_context,  # noqa: E402
                             build_judge_messages, chat, extract_json,
                             is_abstention, run_generation)
from eval.metrics import (STRATEGY_STAGE, abstention_auc, build_report_tables,  # noqa: E402
                          calibrate_tau, context_precision, context_recall,
                          gold_chunks, hallucinated, hallucination_rate, is_hit,
                          load_cases, mean_context_metrics, mrr, ndcg_at_k,
                          print_table_aligned, recall_at_k, score_hits, vec_index)


# ---------------- 代码专用分词 ----------------
def test_tokenize_splits_snake_case_and_keeps_original():
    t = tokenize("hybrid_search")
    assert "hybrid" in t
    assert "search" in t
    assert "hybrid_search" in t          # 原名保留：两个写法都能被 "hybrid" 命中


def test_tokenize_splits_camel_case():
    t = tokenize("hybridSearch")
    assert "hybrid" in t
    assert "search" in t


def test_tokenize_handles_chinese_bigrams():
    """中文没有空格边界：按单字 + 双字 bigram 处理。"""
    t = tokenize("上下文压缩")
    assert "上下" in t
    assert "压缩" in t


# ---------------- AST 切片 ----------------
def test_chunker_splits_functions_and_methods_separately(tmp_path):
    src = (
        "class Retriever:\n"
        "    def rerank(self, q, docs):\n"
        "        return docs\n"
        "\n"
        "def helper():\n"
        "    return 1\n"
    )
    p = tmp_path / "m.py"
    p.write_text(src, encoding="utf-8")

    chunks = chunk_file(str(p), str(tmp_path))
    symbols = [c["meta"].get("symbol") for c in chunks]

    # 方法名带类名前缀：搜 "rerank" 不会命中一堆同名函数
    assert "Retriever.rerank" in symbols
    assert "helper" in symbols
    assert any(c["meta"]["kind"] == "method" for c in chunks)


def test_chunk_id_is_derived_from_path_and_lines(tmp_path):
    """id 由 path:start-end 派生 → 重建索引幂等，也能直接当评测 gold 引用。"""
    p = tmp_path / "m.py"
    p.write_text("def a():\n    return 1\n", encoding="utf-8")
    chunks = chunk_file(str(p), str(tmp_path))
    assert all(c["id"].startswith("m.py:") for c in chunks)
    assert len({c["id"] for c in chunks}) == len(chunks)      # 无重复


def test_chunker_falls_back_on_syntax_error(tmp_path):
    """坏文件不能中断整个索引构建。"""
    p = tmp_path / "bad.py"
    p.write_text("def broken(:\n", encoding="utf-8")
    chunks = chunk_file(str(p), str(tmp_path))                # 不该抛
    assert isinstance(chunks, list)


# ---------------- 回归：性能/正确性重构后的不变量 ----------------
def test_bm25_inverted_matches_bruteforce():
    """倒排版 BM25 的打分必须和暴力全扫描完全一致（重构时的等价性锁）。"""
    import math as m
    docs = [
        "def execute_tool_calls(tool_calls): ...",
        "the executor collects futures in submission order",
        "双路召回：BM25 词法 + bge_m3 向量，RRF 融合",
        "def execute_tool_calls(tool_calls, config): ...",
    ]
    bm = BM25(docs)
    # 暴力参考实现
    ref = BM25.__new__(BM25)
    ref.k1, ref.b = bm.k1, bm.b
    ref.tokens = [tokenize(d) for d in docs]
    ref.lens = [len(t) for t in ref.tokens]
    ref.avg = sum(ref.lens) / len(ref.lens)
    df = {}
    for t in ref.tokens:
        for w in set(t):
            df[w] = df.get(w, 0) + 1
    ref.idf = {w: m.log(1 + (len(docs) - c + 0.5) / (c + 0.5)) for w, c in df.items()}
    for q in ["execute_tool_calls", "futures order", "RRF 融合", "不存在的词xyz"]:
        got = bm.scores(q)
        want = []
        for i, tf_map in enumerate([{w: t.count(w) for w in set(t)} for t in ref.tokens]):
            s = 0.0
            for w in tokenize(q):
                f = tf_map.get(w, 0)
                if not f:
                    continue
                denom = f + ref.k1 * (1 - ref.b + ref.b * ref.lens[i] / ref.avg)
                s += ref.idf.get(w, 0.0) * f * (ref.k1 + 1) / denom
            want.append(s)
        assert all(abs(g - w) < 1e-9 for g, w in zip(got, want)), q


def test_index_drops_chunks_of_deleted_files(tmp_path, monkeypatch):
    """删除文件后重建索引：它的 chunk 必须消失，不能永远残留。"""
    from rag.store import IndexStore
    import rag.store as S

    (tmp_path / "a.py").write_text("def alpha(): pass\n", encoding="utf-8")
    (tmp_path / "b.py").write_text("def beta(): pass\n", encoding="utf-8")

    vecs = iter([[0.1, 0.2], [0.3, 0.4], [0.5, 0.6]])
    monkeypatch.setattr(S, "embed", lambda texts: [next(vecs) for _ in texts])

    store = IndexStore(str(tmp_path / ".rag_index"))
    store.build(str(tmp_path), force=True, verbose=lambda *_: None)
    assert {c["meta"]["path"] for c in store.chunks} == {"a.py", "b.py"}

    (tmp_path / "b.py").unlink()                # 删掉 b.py
    vecs2 = iter([[0.1, 0.2]])                  # a.py 没改，0 个新 chunk 要 embed
    monkeypatch.setattr(S, "embed", lambda texts: [next(vecs2) for _ in texts])
    store.build(str(tmp_path), verbose=lambda *_: None)
    paths = {c["meta"]["path"] for c in store.chunks}
    assert "b.py" not in paths                  # 修复前：b.py 的 chunk 会残留
    assert paths == {"a.py"}


# ---------------- 加权 RRF ----------------
def test_rrf_weights_change_fusion_order():
    """加权 RRF：给某一路更高权重，它的候选应排到前面。"""
    lex, vec = [10, 11, 12], [11, 12, 10]
    assert rrf([lex, vec], weights=[1.0, 1.0])[0] == 11      # 两路都排第 2，并列第一
    # 词法降权后，两路都命中的 11 应让位给只在向量路高排的文档
    assert rrf([lex, vec], weights=[0.1, 1.0])[0] == 11
    assert rrf([lex, vec], weights=[0.1, 1.0]).index(12) < rrf([lex, vec], weights=[0.1, 1.0]).index(10)


# ==================== 自我评测集：四档递进 × 两个指标 ====================
# 从"只有切片"开始，一档加一个组件，四档跑**同一套** query，档与档之间的差
# 就是"这个组件到底带来了什么"（档位定义见下面的 STAGES）。
#
# 指标为什么要两个：只有 recall 的优化是假的——把召回做高最省事的办法是多捞，
# 多捞必然把"这个项目里根本没有答案"的问题也一起捞进来。所以每张表同时报
# **recall@5** 和 **对抗问题幻觉率**。
#
# 跑法：uv run pytest tests/test_rag.py -s -k eval
# 需要 Ollama（query 要真 embedding，且必须和建索引用的是同一个模型）；
# ③④ 两档另需本机 rerank 服务，不在时直接 skip —— 降级成纯 RRF 的结果
# 不能算成"重排的效果"。

CASES_PATH = os.path.join(ROOT, "eval", "cases.jsonl")
INDEX_DIR = os.path.join(ROOT, ".rag_index")
K = 5                       # 和 eval/result.md 的 recall@5 同一口径

# 四档：后者 = 前者 + 正好一个组件。None = 这一档不检索（切片档）
STAGES = [
    ("① 切片", None),
    ("② +混合检索", "hybrid"),                  # BM25 + 向量 + RRF
    ("③ +重排", "hybrid+rerank_noroute"),       # 上一档 + cross-encoder
    ("④ +路由", "hybrid+rerank+route"),         # 上一档 + 词法路路由
]

# 对抗集（out_of_scope / near_miss 两类）已抽到 eval/adversarial.py：
# 那个文件被 rag/config.py 排除出索引，否则对抗题正文进语料，幻觉率会假性变差。


def _w(s):
    """终端显示宽度：中日韩字符占两列，否则按一列算。

    f-string 的 {:<14} 按**字符数**补空格，中文一字符两列宽，表就歪了。
    """
    return sum(2 if ord(c) > 0x2E80 else 1 for c in s)


def _named_symbols(store, query):
    """query 里点名的符号名——去索引里核对过、确实存在的那种。

    用**原始写法**匹配，不拆下划线和驼峰：query 写 `rrf` / `safe_path` 就该对上
    同名符号，而不是拆成 rrf/safe/path 之后到处都能蒙中（按分词碎片匹配时，
    `camelCase` 拆出的 `case` 会把正确的标注误报成漂移，`rrf` 又因为整个语料
    到处都在提它而躲过检查——两个方向都错）。
    """
    named = set(_TOKEN_RE.findall(query))
    symbols = [ch["meta"].get("symbol") or "" for ch in store.chunks]
    return sorted({w for w in named if len(w) >= 3 and any(w in s for s in symbols)})


@pytest.fixture(scope="session")
def evaluated():
    """四档 × 两套 query（可解答 + 对抗）一次跑完，返回结果包。

    session 级不是为了省事：39 条 query 跑一遍链路要十几秒（光 query
    embedding 就约 6s），每个断言各跑一遍的话，整个文件会慢到没人愿意跑。
    """
    import math

    from rag import config
    from rag.embedder import embed, health_check
    from rag.reranker import get_reranker
    from rag.retriever import Retriever
    from rag.store import IndexStore, normalize

    ok, msg = health_check()
    if not ok:
        pytest.skip(f"自评测要真 embedding（{msg}）")
    if config.RERANK_ENABLED:
        print("[eval] 重排档在 CPU 上跑 cross-encoder，约 0.4s/条候选，"
              "两档下来要几分钟（模型只加载一次）", flush=True)

    cases = load_cases(CASES_PATH)
    adv = ADVERSARIAL_CASES
    store = IndexStore(INDEX_DIR)
    # 增量重建：没改过的文件复用旧向量，改过的重算 —— 评测的永远是当前工作区
    # （改了 rag/chunker.py 的话要 uv run python scripts/build_index.py --force：
    #   chunker 变了不会改文件 mtime，增量重建察觉不到）
    store.build(ROOT, verbose=lambda *_: None)

    # 两套 query 一起批量 embedding：逐条调 Ollama 每次约 2s，批量一次搞定
    queries = [c["query"] for c in cases] + [a["query"] for a in adv]
    vecs = embed(queries)
    cache = {q: normalize(v) for q, v in zip(queries, vecs)}
    vby = vec_index(store)              # chunk id -> 向量，量"自信度"用

    reranker = get_reranker(warn=lambda *_: None)
    retriever = Retriever(store, reranker, embed_fn=lambda q: cache[q])

    strategies = ["lexical", "vector", "hybrid", "hybrid_routed"]
    if reranker.name == "cross-encoder":
        strategies += ["hybrid+rerank_noroute", "hybrid+rerank+route"]

    # 一次检索 pool_k（召回池口径），前 K 条就是 k=K 的结果 —— 候选池
    # pool = fused[:recall_k] 与传进来的 k 无关，重排也是对整个池打分后才截断
    # （见 rag/retriever.py 的 retrieve）。所以下面 recall@K 那批断言的字面值
    # 和以前完全一样，只是顺带拿到了 recall@pool_k 这一档数据。
    pool_k = config.RECALL_K
    hits, adv_hits, latencies = {}, {}, {}
    for s in strategies:
        latencies[s], hits[s], adv_hits[s] = [], [], []
        for c in cases:
            t0 = time.perf_counter()
            hits[s].append(retriever.retrieve_by_strategy(c["query"], s, k=pool_k))
            latencies[s].append((time.perf_counter() - t0) * 1000)
        for a in adv:
            adv_hits[s].append(retriever.retrieve_by_strategy(a["query"], s, k=pool_k))
    top5 = {s: [r[:K] for r in hits[s]] for s in strategies}      # 交付集 = 前 K 条
    adv_top5 = {s: [r[:K] for r in adv_hits[s]] for s in strategies}

    def _row(s):
        n = len(cases)
        ctx = mean_context_metrics(top5[s], cases, store.chunks, K)
        return {
            "strategy": s,
            "stage": STRATEGY_STAGE.get(s, "—"),
            f"recall@{K}": sum(recall_at_k(r, c, K) for r, c in zip(top5[s], cases)) / n,
            f"mrr@{K}": sum(mrr(r, c, K) for r, c in zip(top5[s], cases)) / n,
            f"ndcg@{K}": sum(ndcg_at_k(r, c, K) for r, c in zip(top5[s], cases)) / n,
            f"recall@{pool_k}": sum(recall_at_k(r, c, pool_k)
                                    for r, c in zip(hits[s], cases)) / n,
            "recall": sum(recall_at_k(r, c, pool_k) for r, c in zip(hits[s], cases)) / n,
            "mrr": sum(mrr(r, c, K) for r, c in zip(top5[s], cases)) / n,
            "ndcg": sum(ndcg_at_k(r, c, K) for r, c in zip(top5[s], cases)) / n,
            "context_recall": ctx["recall"],
            "context_precision": ctx["precision"],
            "p50_ms": sorted(latencies[s])[len(latencies[s]) // 2],
            "p95_ms": sorted(latencies[s])[min(int(0.95 * len(latencies[s])),
                                               len(latencies[s]) - 1)],
            "errors": 0,
        }

    rows = [_row(s) for s in strategies]
    rows_by = {r["strategy"]: r for r in rows}
    if "hybrid+rerank+route" in rows_by:
        rows_by["hybrid+rerank"] = rows_by["hybrid+rerank+route"]     # 旧名兼容

    # 切片档：每条 case 的 gold 行区间落在哪些 chunk 上
    gold_by_case = [gold_chunks(store.chunks, c) for c in cases]
    miss = {s: [f'{c["path"]}:{c["lines"][0]}' for c, r in zip(cases, top5[s])
                if not any(is_hit(x, c) for x in r)] for s in strategies}
    routed_in = [c for c in cases if store.has_distinctive_code_token(c["query"])]

    # ---------------- 对抗集：拒答线与幻觉率 ----------------
    def _best(hits_list, qvec, at):
        s = score_hits(hits_list, qvec, vby, at)
        return max(s) if s else 0.0

    def _corpus_top1(qvec):
        """① 切片档不检索：它的"top-1"就是全库最像的那条 —— 幻觉素材的上界。"""
        ch = max(store.chunks, key=lambda c: math.sumprod(qvec, c["vec"]))
        return [{"id": ch["id"], "text": ch["text"], "meta": ch["meta"]}]

    # 拒答线 tau 从**可解答集**上标定，与检索策略无关（只取决于模型和语料）：
    # 取"全库最高余弦"的 p10 —— 答得出来的题里最没底的那道有多没底，
    # 低于这个水平就该拒答。换模型/换语料它会自动重新标定，不用手调。
    pos_best = [max(math.sumprod(cache[c["query"]], ch["vec"]) for ch in store.chunks)
                for c in cases]
    tau = calibrate_tau(pos_best, q=0.10)

    stage_rows = []
    for label, s in STAGES:
        if s is not None and s not in rows_by:
            continue        # rerank 服务没起，③④ 两档没法评（不拿降级结果充数）
        if s is None:                                   # ① 切片
            neg1 = [_best(_corpus_top1(cache[a["query"]]), cache[a["query"]], 1) for a in adv]
            negk = neg1
            pos1 = pos_best
            recall = sum(1 for m in gold_by_case if m) / max(len(cases), 1)
        else:
            neg1 = [_best(h, cache[a["query"]], 1) for h, a in zip(adv_top5[s], adv)]
            negk = [_best(h, cache[a["query"]], K) for h, a in zip(adv_top5[s], adv)]
            pos1 = [_best(h, cache[c["query"]], 1) for h, c in zip(top5[s], cases)]
            recall = rows_by[s][f"recall@{K}"]
        out1 = [v for v, a in zip(neg1, adv) if a["kind"] == "out_of_scope"]
        near1 = [v for v, a in zip(neg1, adv) if a["kind"] == "near_miss"]
        stage_rows.append({
            "stage": label, "strategy": s, "recall": recall,
            "halluc": sum(v >= tau for v in neg1) / max(len(neg1), 1),
            "halluc_out": sum(v >= tau for v in out1) / max(len(out1), 1),
            "halluc_near": sum(v >= tau for v in near1) / max(len(near1), 1),
            "halluc_atk": sum(v >= tau for v in negk) / max(len(negk), 1),
            "auc": abstention_auc(pos1, neg1),
            "neg1": neg1,           # 留着给报告打印"哪几条被判成幻觉"
        })

    # 报告先打：任何一条断言炸了，你也能看到完整对比表。
    # 打的就是 eval/run.py 那三张表（列定义同出一源：metrics.build_report_tables），
    # pytest -s 看到的和报告一模一样。第三张要真调模型，不在单测里跑，所以只打前两张。
    unreachable = [c for c, m in zip(cases, gold_by_case) if not m]
    print(f"\n==== 检索自评测：{len(cases)} 条可解答 + {len(adv)} 条对抗，"
          f"召回池 {pool_k} / 交付 {K}，索引取当前工作区 ====")
    print(f"① 切片      gold 可达 {len(cases) - len(unreachable)}/{len(cases)}"
          f"   （不可达 = 该改标注，不是该改检索）")
    for t in build_report_tables(rows, [], pool_k, K, stage_labels=STAGES,
                                 gen_model=None)[:2]:
        print_table_aligned(t["title"], t["cols"], t["rows"], t["footnotes"])
    for s in strategies:
        print(f"    {s:22s} 漏检 {len(miss[s]):2d}: {', '.join(miss[s])}")
    print(f"    路由让词法路发言 {len(routed_in)}/{len(cases)} 条 query")
    # 旧的检索侧幻觉代理（余弦 vs 拒答线 tau）不再进报告 —— 报告里的 Hallucination
    # 是**生成层**的，两者不是同一个东西。但这些数仍被下面的断言守着，所以照打。
    print(f"\n[旧口径] 拒答线 tau = {tau:.3f}（可解答集全库最高余弦的 p10）")
    for r in stage_rows:
        print(f"    {r['stage']:12s} recall@{K} {r['recall']:.3f} · 幻觉@1 {r['halluc']:.3f}"
              f" · 域外 {r['halluc_out']:.3f} · 近义 {r['halluc_near']:.3f}"
              f" · 可分性 {r['auc']:.3f}")

    return {"cases": cases, "adv": adv, "store": store, "rows": rows_by,
            "gold_chunks": gold_by_case, "miss": miss, "routed_in": routed_in,
            "tau": tau, "pos_best": pos_best, "stage_rows": stage_rows,
            "stage_by_label": {r["stage"]: r for r in stage_rows},
            "hits": hits, "top5": top5, "pool_k": pool_k}


def test_eval_1_slice_gold_is_reachable(evaluated):
    """① 切片档：先确认这套评测集本身是"答得出"的。

    gold 行区间没被切成任何 chunk 的话，后面每一档的 recall 都是在给切分 /
    标注的错背锅，所以这是整条链路的第一道断言。
    """
    cases, gold = evaluated["cases"], evaluated["gold_chunks"]
    unreachable = [f'{c["path"]}:{c["lines"][0]}' for c, m in zip(cases, gold) if not m]
    assert not unreachable, f"这些 gold 对不上任何 chunk：{unreachable}"

    # 更强的第二道：query 里点名了标识符（rrf / safe_path 这类稀有词）时，
    # gold chunk 的正文里就必须真的出现它。只查"可达"是查不出标注漂移的——
    # 行号偏出去几十行，照样会落在别的 chunk 上，看着还是"可达"。
    drift = []
    for c, chunks in zip(cases, gold):
        text = " ".join(ch["text"] for ch in chunks).lower()
        lost = [w for w in _named_symbols(evaluated["store"], c["query"])
                if w.lower() not in text]      # 正文统一小写比对，camelCase 也得对上
        if lost:
            drift.append(f'{c["path"]}:{c["lines"][0]} << {c["query"][:22]}… 正文里没有 {lost}')
    assert not drift, "疑似标错（gold 行号漂移）：\n  " + "\n  ".join(drift)


def test_eval_2_hybrid_beats_the_weak_route(evaluated):
    """② 在切片之上加混合检索：融合结果不该比任何单路差。

    绝对阈值都压在实测值下方留了余量（bge-m3 + 当前语料下：词法 0.345、
    向量 0.862）。换 embedding 模型或大改切分，这些数字要重测。
    """
    r = evaluated["rows"]
    assert r["lexical"][f"recall@{K}"] >= 0.30, "纯词法基线掉了"
    assert r["vector"][f"recall@{K}"] >= 0.80, "纯向量基线掉了"
    assert r["hybrid"][f"recall@{K}"] >= r["lexical"][f"recall@{K}"], \
        "融合出来还不如只有词法一路"


def test_eval_3_rerank_trades_recall_for_safety(evaluated):
    """③ 在融合结果之上加重排：在路由版上 recall 持平，幻觉率下降。

    五方向评测表明，重排对不同方向的影响完全不同：函数定位/调用关系（点名
    标识符）本就 1.000，重排不伤也不帮；类职责从 0.833 掉到 0.667（通用语义
    模型在代码上没练过，挤掉对的）；语义从 0.333 升到 0.500（靠语义理解把自然
    语言 query 的正确 chunk 提上来）。汇总看 ② → ③ recall 0.724 → 0.759 略升，
    幻觉率 0.222 → 0.167 下降——两个指标一起看才说得清。

    真服务不在时这一档根本不在 rows 里 —— 降级成纯 RRF 却被当成"重排的效果"
    才是真问题，所以这里宁可 skip 也不拿降级结果充数。
    """
    rows = evaluated["rows"]
    if "hybrid+rerank" not in rows:
        pytest.skip("没有可用的 cross-encoder：uv add onnxruntime tokenizers 后跑 "
                    "scripts/download_reranker.py，或起 llama-server --rerank "
                    "-m bge-reranker-v2-m3.gguf --pooling rank --port 8080")
    before, after = rows["hybrid_routed"], rows["hybrid+rerank"]

    # 召回：允许掉，但掉太多说明重排模型跟这个语料八字不合（实测 0.750）
    assert after[f"recall@{K}"] >= 0.75, f"重排把召回掉太多了：{after[f'recall@{K}']:.3f}"
    # 安全：这是重排档真正该拿分的地方。这里守的是"别把对抗题抬上来"，而不是
    # 一个写死的降幅 —— 语料一变（比如清掉一批注释里的中文噪声），② 档的基线
    # 幻觉率本身就会降，留给 ③ 的下降空间随之变小，写死 0.10 会变成假警报。
    st = evaluated["stage_by_label"]
    assert st["③ +重排"]["halluc"] <= st["② +混合检索"]["halluc"] + 0.02, \
        "重排把对抗题的自信度抬上来了（压下去才是它该干的活）"
    assert st["③ +重排"]["auc"] <= st["② +混合检索"]["auc"] + 0.02, \
        "重排没能改善「答得出 / 答不出」的可分性"


def test_eval_4_routing_recovers_what_naive_fusion_lost(evaluated):
    """④ 加检索路由：这个项目里最反直觉的一步。

    等权融合（hybrid）居然比纯向量还差——中文语义 query 在词法路上只能匹配到
    注释里的 bigram 噪声，而噪声只要排进词法路 top-1，就足以盖掉向量路排第二的
    正确结果。路由只在 query 含稀有标识符时才放行词法路，把这类噪声挡在门外。
    """
    rows = evaluated["rows"]
    routed, vector, hybrid = rows["hybrid_routed"], rows["vector"], rows["hybrid"]
    assert routed[f"recall@{K}"] >= hybrid[f"recall@{K}"], "路由没把无条件融合掉的分捞回来"
    assert routed[f"recall@{K}"] >= vector[f"recall@{K}"], "路由版还不如纯向量，判据该重调了"
    assert routed[f"recall@{K}"] >= 0.80, "路由版整体掉了（实测 0.862）"
    # 上面两条也可能只是"路由压根没生效"的巧合，确认它真的在分流转
    assert 0 < len(evaluated["routed_in"]) < len(evaluated["cases"]), "路由要么全放行要么全拦"


# ---------------- 对抗集自检（不需要 Ollama） ----------------
@pytest.fixture(scope="session")
def corpus():
    """只要语料文本——对抗集自检是纯文本扫描，不该被 embedding 服务卡住。"""
    from rag.store import IndexStore

    store = IndexStore(INDEX_DIR).load()
    if not store.chunks:
        pytest.skip("没有索引：先 uv run python scripts/build_index.py")
    return store


def test_adv_set_is_really_unanswerable(corpus):
    """out_of_scope 那几条对抗题，主题词在语料里必须一个字都没有。

    守的是**评测集本身的质量**：哪天 README 里写了句"下一步接 Redis"，
    那条题就不再是幻觉题而是漏检题——不拦住的话幻觉率会莫名其妙地涨，
    涨完还得回头怀疑是不是检索退化了。
    """
    text = "\n".join(c["text"] for c in corpus.chunks).lower()
    leaked = [f'{a["query"][:16]}… 语料里出现了「{w}」'
              for a in ADVERSARIAL_CASES for w in a.get("must_not", ())
              if w.lower() in text]
    assert not leaked, "对抗集失效（这些主题语料里其实有）：\n  " + "\n  ".join(leaked)

    # 两类都要有题，否则"域外好拒、近义难拒"这个区分根本看不出来
    kinds = {a["kind"] for a in ADVERSARIAL_CASES}
    assert kinds == {"out_of_scope", "near_miss"}, f"对抗集两类都要有，现在是 {kinds}"


# ---------------- 四档 × 两指标 ----------------
def test_stage_recall_and_hallucination_move_in_opposite_directions(evaluated):
    """整张表的核心：召回往上走的时候，幻觉率不许跟着往上走。

    只报 recall 的优化是假的——多捞总能多中，代价是"这个项目里没有答案"
    的问题也被捞了个垫背的上下文，模型顺着就编。这两条一起看才叫评测。
    """
    st = evaluated["stage_by_label"]
    s2 = st["② +混合检索"]
    if "④ +路由" not in st:
        pytest.skip("rerank 服务未起，③④ 两档没法评：llama-server --rerank "
                    "-m bge-reranker-v2-m3.gguf --pooling rank --port 8080")

    s3, s4 = st["③ +重排"], st["④ +路由"]
    # 召回：端到端（④）不能比只加融合（②）的时候差
    assert s4["recall"] >= s2["recall"] - 0.02, \
        f"④ 召回掉了：{s4['recall']:.3f} < {s2['recall']:.3f}"
    # 幻觉率：召回涨上来的同时，不该把更多对抗题也一起抬过拒答线。
    # 留 0.05 容差：重排/路由是在 20 条候选里重排，top-1 换人会有抖动。
    assert s4["halluc"] <= s2["halluc"] + 0.05, \
        f"④ 幻觉率反而涨了：{s4['halluc']:.3f} > {s2['halluc']:.3f}"
    assert s3["halluc"] <= s2["halluc"] + 0.05, "③ 重排把对抗题抬上来了"


def test_stage_slice_is_the_upper_bound_of_both_metrics(evaluated):
    """① 切片档是两条指标共同的**理论边界**，不是一条"更差的检索"。

    - 召回：gold 切不出来，后面几档再怎么调都召回不了（切片是召回的上限）；
    - 幻觉：全库最像的那条就是素材上界，检索只能决定"让不让它进 top-1"
      （切片是幻觉率的下限）。
    把这两条写进断言，是为了防止有人看到 ① 的数字最好看就以为它最强。
    """
    st = evaluated["stage_by_label"]
    s1 = st["① 切片"]
    assert s1["recall"] == 1.0, f"有 gold 切不出来：recall={s1['recall']:.3f}"

    if "④ +路由" in st:
        # 检索档的 top-1 只能从切片给的东西里挑，所以不可能比全库最高分还高
        assert st["④ +路由"]["halluc"] <= s1["halluc"] + 1e-9, \
            "检索档的幻觉率不该超过素材上界"


def test_hallucination_metric_with_fake_vectors():
    """尺子本身准不准：不依赖 Ollama，用假向量把幻觉率的判据跑一遍。

    真机那档要起服务才跑得动，度量逻辑本身不该跟着一起没人守。
    """
    vby = {"same": [1.0, 0.0], "mid": [0.7, 0.7], "ortho": [0.0, 1.0]}
    q = [1.0, 0.0]

    # 正交 = 一点都不沾；同向 = 完全对上
    assert score_hits([{"id": "ortho"}], q, vby) == [0.0]
    assert score_hits([{"id": "same"}], q, vby) == [1.0]
    assert not hallucinated([{"id": "ortho"}], q, vby, tau=0.5)
    assert hallucinated([{"id": "same"}], q, vby, tau=0.5)

    # 三条：1.0 / 0.7 / 0.0
    runs = [([{"id": "same"}], q), ([{"id": "mid"}], q), ([{"id": "ortho"}], q)]
    assert hallucination_rate(runs, vby, 0.5) == pytest.approx(2 / 3)
    # 拒答线抬高 = 判定更严 = 幻觉率单调下降（0.7 那条被放过）
    assert hallucination_rate(runs, vby, 0.9) == pytest.approx(1 / 3)
    # 查不到向量的 chunk 记 0，不是抛错
    assert score_hits([{"id": "已删除的chunk"}], q, vby) == [0.0]

    # 拒答线的标定：q=0 取最小值，全一样时取那个值
    assert calibrate_tau([0.3, 0.8, 0.5], q=0.0) == 0.3
    assert calibrate_tau([0.42] * 10) == 0.42
    assert calibrate_tau([]) == 0.0


def test_rerank_stage_actually_reorders(tmp_path, monkeypatch):
    """重排档的接线：候选池来自 RRF 融合，最终顺序由 reranker 说了算。

    用假 reranker，不依赖 llama-server —— 真服务不在时，这一档的代码路径
    也不至于完全没人守（上面那档会 skip）。
    """
    from rag.retriever import Retriever
    from rag.store import IndexStore
    import rag.store as S

    class ReverseReranker:
        name = "cross-encoder"          # 冒充真服务，才会走重排这条分支

        def __init__(self):
            self.calls = []

        def rerank(self, query, docs, top_k):
            self.calls.append((query, docs))
            return list(range(len(docs)))[::-1][:top_k]

    (tmp_path / "a.py").write_text(
        "def alpha_search(q):\n    return q\n\n\ndef beta_search(q):\n    return q\n",
        encoding="utf-8")
    monkeypatch.setattr(S, "embed", lambda texts: [[1.0, 0.0] for _ in texts])
    store = IndexStore(str(tmp_path / ".rag_index"))
    store.build(str(tmp_path), force=True, verbose=lambda *_: None)

    rr = ReverseReranker()
    r = Retriever(store, rr, embed_fn=lambda q: [1.0, 0.0])
    plain = [h["id"] for h in r.retrieve("alpha_search", k=2, use_rerank=False)]
    reranked = [h["id"] for h in r.retrieve("alpha_search", k=2, use_rerank=True)]

    assert r.stats["reranked"] is True, "reranker 没被调用（静默降级成纯 RRF 了）"
    assert rr.calls, "reranker 没收到 query 和候选池"
    assert len(rr.calls[0][1]) == len(plain), "送进重排的池子不该只是最终 top-k"
    assert reranked == plain[::-1], "最终顺序应该由 reranker 决定"


# ==================== 三维度：尺子本身的单测（不需要任何服务） ====================
# 报告只出三张表，但尺子准不准必须单独守 —— 真机那档要起 Ollama + 花钱调模型，
# 不能因为跑不动就没人管算法。这一组全部用假 chunk / 假 chat。


def _fake_chunk(cid, path, start, end, text=""):
    """造一条检索结果：形状与 Retriever.retrieve 的返回一致（表二、重排都在吃它）。"""
    return {"id": cid, "text": text, "score": None,
            "meta": {"path": path, "start_line": start, "end_line": end}}


def test_metrics_library_keeps_the_surface_corpus_langchain_imports():
    """eval/corpus_langchain/* 直接 import 这些名字（evaluator.py:29、run_eval.py:59、
    run_eval.baseline.py:42）。删掉或改名，那边直接 ImportError —— 而 corpus 那套
    平时不在本仓库跑，坏了没人知道。所以在这里把导入面钉死。"""
    import eval.metrics as m
    frozen = ("CAT_LABELS", "STAGES", "STRATEGIES", "abstention_auc", "calibrate_tau",
              "chunk_coverage", "evaluate_strategy", "far_from_scores", "latency_stats",
              "load_cases", "mrr", "ndcg_at_k", "print_table", "recall_at_k",
              "routing_gain", "run_eval", "score_hits", "vec_index")
    missing = [n for n in frozen if not hasattr(m, n)]
    assert not missing, f"eval.metrics 少了 {missing}，corpus_langchain 会炸"


def test_context_metrics_with_fake_chunks():
    """Context Recall / Precision 的四个边界：多 gold、零相关、gold 不在索引里、单 gold。"""
    src = "a.py"
    case = {"query": "q", "path": src, "lines": [10, 20]}
    gold_a = _fake_chunk("a.py:1-15", src, 1, 15)      # 与 gold 区间 [10,20] 重叠
    gold_b = _fake_chunk("a.py:16-30", src, 16, 30)    # 也重叠 -> 第二个 gold chunk
    other = _fake_chunk("a.py:40-60", src, 40, 60)     # 不重叠
    far = _fake_chunk("b.py:1-9", "b.py", 1, 9)        # path 都不对

    assert gold_chunks([gold_a, gold_b, other], case) == [gold_a, gold_b]

    # 双 gold 只召回一条：recall 掉一半；但那一条排第 1 时 precision 仍然是 1.000
    # （precision 的分母是"召回到的相关条数"，不是 gold 总数）。
    assert context_recall([gold_a, other], case, [gold_a, gold_b, other], 5) == 0.5
    assert context_precision([gold_a, other], case, [gold_a, gold_b, other], 5) == 1.0

    # 一条相关的都没召回（含空检索）：recall 0.0，precision 也记 0.0 —— 不是 1.0。
    # 空集上的 precision 没定义，记 1.0 会让"什么都没捞到"看起来最精准。
    assert context_recall([other], case, [gold_a, gold_b, other], 5) == 0.0
    assert context_precision([other], case, [gold_a, gold_b, other], 5) == 0.0
    assert context_recall([], case, [gold_a, gold_b], 5) == 0.0
    assert context_precision([], case, [gold_a, gold_b], 5) == 0.0

    # gold 不在索引里（标注漂移）：recall 记 1.0 不在这里扣分，交给 chunk_coverage /
    # test_eval_1 去暴露数据问题；precision 没有相关的可算，记 0.0。
    assert context_recall([far], case, [far], 5) == 1.0
    assert context_precision([far], case, [far], 5) == 0.0

    # 单 gold 时 precision 退化成 1/rank —— 与 mrr 完全同值（39 条里 33 条是这种情况，
    # 这就是表一表二必须在脚注里自曝"两个指标可能同源"的原因）。
    assert context_precision([gold_a, other], case, [gold_a, other], 5) == 1.0
    assert context_precision([other, gold_a], case, [gold_a, other], 5) == 0.5
    assert context_precision([other, gold_a], case, [gold_a, other], 5) == mrr([other, gold_a], case, 5)


def test_mean_context_metrics_averages_per_case_not_per_chunk():
    """逐条算再平均：先合并分母会把多 gold 的题权重放大，均值就成了另一回事。"""
    case = {"query": "q", "path": "a.py", "lines": [10, 20]}
    gold_a = _fake_chunk("a.py:1-15", "a.py", 1, 15)
    gold_b = _fake_chunk("a.py:16-30", "a.py", 16, 30)
    other = _fake_chunk("a.py:40-60", "a.py", 40, 60)
    chunks = [gold_a, gold_b, other]

    got = mean_context_metrics([[gold_a], [other, gold_a, gold_b]], [case, case], chunks, 5)
    # 第一条只捞到 1/2 个 gold；第二条两个都捞到了
    assert got["recall"] == (0.5 + 1.0) / 2
    # 第一条 precision = 1/1；第二条 rels=[0,1,1] -> (1/2 + 2/3)/2
    assert got["precision"] == pytest.approx((1.0 + (0.5 + 2 / 3) / 2) / 2)


def test_recall_pool_sees_what_the_delivered_top5_hides():
    """池子口径（RECALL_K）与交付前 5 口径必须真的分得开 —— 这正是"召回捞到了、
    重排/截断弄丢了"的样子，也是把 recall 改成池子口径的理由。"""
    case = {"query": "q", "path": "a.py", "lines": [100, 110]}
    gold = _fake_chunk("a.py:100-110", "a.py", 100, 110)
    noise = [_fake_chunk(f"a.py:{i}-{i + 9}", "a.py", i, i + 9) for i in range(1, 7)]
    hits = noise + [gold]                             # gold 排第 7 位

    assert recall_at_k(hits, case, 20) == 1.0         # 池子里有 -> 召回没责任
    assert recall_at_k(hits, case, 5) == 0.0          # 前 5 条没有 -> 是交付段丢的


# ---------------- 生成可靠性：解析、拒答检测、编排 ----------------


def test_extract_json_survives_what_models_actually_emit():
    assert extract_json('{"n_claims": 2, "n_supported": 1}')["n_claims"] == 2
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}          # 围栏
    assert extract_json("```\n{\"a\": 1}\n```") == {"a": 1}            # 没写 json 的围栏
    # 先说一段话再给 JSON：raw_decode 只吃第一个对象，后面的解释自动忽略
    assert extract_json('好的，结果如下：{"a": 1} 以上。') == {"a": 1}
    # 抠不出来一律 None —— 上层要能把它数成 parse_failed，不能伪装成 0 分
    assert extract_json("完全不是 JSON") is None
    assert extract_json("") is None
    assert extract_json(None) is None
    assert extract_json("[1, 2]") is None                             # 不是对象


def test_abstention_is_detected_by_the_fixed_string():
    assert is_abstention(REFUSAL)
    assert is_abstention("先说一句。" + REFUSAL)
    assert not is_abstention("用的是 bge-m3。")
    assert not is_abstention("")


def _fake_chat(refuse_marker="拒绝"):
    """假 chat：按 system prompt 的用途分流，不打网络（与 Retriever 注入 embed_fn 同路子）。"""
    def fake(model, messages, json_object=False):
        system, user = messages[0]["content"], messages[1]["content"]
        if "问答助手" in system:                      # 生成
            return REFUSAL if refuse_marker in user else "答案：上下文里写的是 bge-m3。"
        if "论断" in system:                          # 论断级判官
            return '{"n_claims": 2, "n_supported": 1, "reason": "有一条借了外部知识"}'
        if "asserted" in system:                      # 拒答判官
            return '{"asserted": true, "reason": "给了一个具体名字"}'
        raise AssertionError(f"没见过的 prompt：{system[:30]}")
    return fake


def test_generation_pipeline_metrics_with_fake_chat():
    """把生成档整条链路（生成 -> 拒答检测 -> 判官 -> 汇总）用假 chat 跑一遍。

    验的是编排和口径：拒答要排除在 Faithfulness 分母外、幻觉率要分三段再宏平均、
    作答率要能揭穿"全拒答刷满分"。
    """
    cases = [{"query": "压缩用的是什么", "path": "a.py", "lines": [1, 2]},
             {"query": "拒绝 这一条", "path": "a.py", "lines": [3, 4]}]
    adv = [{"query": "对抗题一", "kind": "out_of_scope"},
           {"query": "拒绝 对抗题二", "kind": "near_miss"}]
    stage_hits = [("① 无上下文", [[] for _ in cases], [[] for _ in adv])]

    rows = run_generation(cases, adv, stage_hits, "fake-model", k=5,
                          chat_fn=_fake_chat(), workers=1)
    r = rows[0]

    # 一条作答（判官判 1/2 支持）、一条拒答：均值只在真的作答了的那条上取
    assert r["faithfulness"] == 0.5
    assert r["claims"] == 2                      # 两句话的回答拿满分会在这一列现形
    assert r["answer_rate"] == 0.5               # 全拒答刷出的满分在这里露馅
    # 域外那条被判官判成"断言了答案" -> 1.0；近义那条拒答了 -> 0.0；可解答那条含未支撑断言 -> 1.0
    assert (r["halluc_ood"], r["halluc_near"], r["halluc_answerable"]) == (1.0, 0.0, 1.0)
    # 总分是三项宏平均（等权），不是 2 条样本合在一起算
    assert r["hallucination"] == pytest.approx((1.0 + 0.0 + 1.0) / 3)
    assert (r["n_ood"], r["n_near"]) == (1, 1)
    assert r["errors"] == 0 and r["parse_failed"] == 0


def test_generation_counts_failures_instead_of_scoring_zero():
    """判官崩了要记 parse_failed 并从分母里剔除，不能当 0 分 ——
    否则一次网络抖动会让 Faithfulness 凭空掉一截，还查不出原因。"""
    def broken_judge(model, messages, json_object=False):
        if "问答助手" in messages[0]["content"]:
            return "答案是 bge-m3。"
        return "这不是 json"                     # 判官跑偏

    cases = [{"query": "q", "path": "a.py", "lines": [1, 2]}]
    rows = run_generation(cases, [], [("①", [[]], [])], "fake-model", k=5,
                          chat_fn=broken_judge, workers=1)
    r = rows[0]
    assert r["parse_failed"] == 1
    assert r["faithfulness"] is None             # 没有可用的判词 -> 不编一个分数出来
    assert r["answer_rate"] == 1.0               # 但它确实是作答了


def test_generation_error_is_not_counted_as_abstention():
    """生成调用失败必须是 error，不能变成"拒答成功" —— 否则接口一挂，
    对抗集拒答率看起来最漂亮，整个维度反向优化。"""
    def dead(model, messages, json_object=False):
        raise RuntimeError("connection reset")

    cases = [{"query": "q", "path": "a.py", "lines": [1, 2]}]
    adv = [{"query": "a", "kind": "out_of_scope"}]
    rows = run_generation(cases, adv, [("①", [[]], [[]])], "fake-model", k=5,
                          chat_fn=dead, workers=1)
    r = rows[0]
    assert r["errors"] == 2                      # 1 条可解答 + 1 条对抗
    assert r["answer_rate"] == 0.0
    assert r["n_ood"] == 0                       # 失败样本进不了域外拒答率的分母
    assert r["hallucination"] is None


def test_response_cache_roundtrip(tmp_path):
    """缓存是"可复现"的唯一来源（temperature=0 也保证不了逐位一致），
    所以它必须能落盘、能重载 —— 报告里每个数字都要能追到一条缓存原文。"""
    from eval.generation import PROMPT_VERSION

    path = str(tmp_path / "c.jsonl")
    msgs = [{"role": "user", "content": "同一个问题"}]
    c1 = ResponseCache(path)
    assert c1.get("m", msgs) is None             # 未命中
    c1.put("m", msgs, "第一次的回答")
    assert c1.misses == 1

    c2 = ResponseCache(path)                     # 重新加载：重跑 0 次网络请求
    assert c2.get("m", msgs) == "第一次的回答"
    assert c2.hits == 1
    # 改了 rubric 就靠它作废旧缓存，否则新旧判词混在一份报告里没人看得出来
    assert PROMPT_VERSION >= 1


def test_response_cache_survives_concurrent_writes(tmp_path):
    """生成档默认 8 线程并发写缓存：不串行的话，同一条记录会被拆成几次 write 交错，
    文件里就多出半个块 —— 下次加载 UnicodeDecodeError，整份缓存（几百次付费调用）
    一起报废。这个测试真的踩过一次线上，不是假想。"""
    from concurrent.futures import ThreadPoolExecutor

    path = str(tmp_path / "c.jsonl")
    cache = ResponseCache(path)
    n = 200
    # 每条都写成 KB 级的中文长回答，足够触发 TextIOWrapper 的分块写
    msgs = [{"role": "user", "content": f"问题{i}"} for i in range(n)]
    values = [f"回答{i}：" + "上下文里写的是 bge-m3。" * 60 for i in range(n)]

    with ThreadPoolExecutor(max_workers=8) as ex:
        list(ex.map(lambda t: cache.put("m", [t[0]], t[1]), zip(msgs, values)))

    reloaded = ResponseCache(path)               # 加载不能抛 UnicodeDecodeError
    assert len(reloaded.data) == n, "并发写丢了记录"
    assert reloaded.get("m", [msgs[7]]) == values[7]


def test_chat_raises_without_key_instead_of_returning_empty(monkeypatch):
    """没配 key 时必须抛错：返回空字符串会被判成"拒答"，然后悄悄美化幻觉率。"""
    from eval.generation import ChatError
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)
    monkeypatch.delenv("DEEPSEEK_BASE_URL", raising=False)
    with pytest.raises(ChatError):
        chat("m", [{"role": "user", "content": "q"}])


# ---------------- 真机生成档（默认不跑：要 API key、要花钱） ----------------

@pytest.mark.skipif(not os.getenv("RAG_EVAL_GEN"),
                    reason="真调模型生成 + 判官：显式 RAG_EVAL_GEN=1 才跑（有 API 成本）")
def test_real_generation_smoke():
    if not os.getenv("DEEPSEEK_API_KEY"):
        pytest.skip("没有 DEEPSEEK_API_KEY")
    cases = load_cases(CASES_PATH)[:1]
    adv = ADVERSARIAL_CASES[:1]
    rows = run_generation(cases, adv, [("① 无上下文", [[]], [[]])], "deepseek-chat",
                          k=5, workers=2, cache=None)
    r = rows[0]
    assert r["errors"] == 0, r
    assert r["answer_rate"] is not None
